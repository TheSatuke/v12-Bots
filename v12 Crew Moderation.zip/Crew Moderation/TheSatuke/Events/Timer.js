const TimeManager = require("../Managers/Time.Manager");
const Settings = require("../Configuration/Settings.json");
module.exports = (user) => {

    const TM = TimeManager;
    setInterval(async () => { 
    await TM.checkDay(Settings.Server.Id);
    }, 5000);    

};

module.exports.config = {
    Event: "ready"
}