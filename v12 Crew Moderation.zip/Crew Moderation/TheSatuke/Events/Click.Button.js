const Settings = require("../Configuration/Settings.json");
const client = global.Client;
const { Client, Discord, MessageEmbed } = require("discord.js");
const moment = require("moment");
const disbut = require('discord-buttons');

moment.locale("tr");
      module.exports = (message) => {
        let etk = Settings.Roles.Etkinlik;
        let cek = Settings.Roles.Cekilis;
            if (button.id === 'XXX') {
                if (button.clicker.member.roles.cache.get(etk)) {
                    button.clicker.member.roles.remove(etk);
                    button.reply.send('Rol Başarıyla Üzerinden Alındı!', true);
                  } else {
                    button.clicker.member.roles.add(etk);
                    button.reply.send('Rol Başarıyla Üzerine Eklendi!', true);
          
                  }
            }
            if (button.id === 'XX') {
                if (button.clicker.member.roles.cache.get(cek)) {
                    button.clicker.member.roles.remove(cek);
                    button.reply.send('Rol Başarıyla Üzerinden alındı!', true);
                } else {
                    button.clicker.member.roles.add(cek);
                    button.reply.send('Rol Başarıyla Üzerine Eklendi!', true);
                }
          
            }

        }
    
module.exports.config = {
    Event: "clickButton"
};
