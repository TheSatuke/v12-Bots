
const client = global.Client;
const { Client, Discord, MessageEmbed } = require("discord.js");
const Settings = require("../Configuration/Settings.json");
module.exports = (oldMessage, newMessage, channel) => {

    var satukeallah;
    if(satukeallah) {
        let allah = message.guild.channels.cache.get(Settings.Server.messageLog) 
        const messageUpdate = new MessageEmbed().setTimestamp()
        if (oldMessage.author.bot) return;
        if (!oldMessage.guild) return;
        if (oldMessage.content == newMessage.content) return;
        allah.send(messageUpdate.setAuthor(`${oldMessage.author.tag} Mesaj Düzenlendi`, oldMessage.author.avatarURL()).setDescription(`<#${oldMessage.channel.id}> kanalında <@!${oldMessage.author.id}> tarafından bir mesaj düzenlendi.
    
\` ➥ \` Eski Mesaj: **${oldMessage.content}**
\` ➥ \` Yeni Mesaj: **${newMessage.content}**`).setColor(Config.EmbedColor).setFooter(Config.Status)); 
      }
    };

module.exports.config = {
    Event: "messageUpdate"
}