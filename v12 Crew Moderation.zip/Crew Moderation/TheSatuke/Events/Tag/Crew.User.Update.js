const { Discord, MessageEmbed, User, GuildMember} = require("discord.js");
const Settings = require("../../Configuration/Settings.json");

/**
 * @param {User} oldUser 
 * @param {User} newUser 
 */
module.exports = async (oldUser, newUser, message, client) => {

    const T1 = ("Champion")
    const T2 = ("champion")
    const T3 = ("Champ")
    const T4 = ("champ")
    const T5 = ("1949")
    const T6 = ("'")
    const Disc = "1949"
    const R = Settings.Tag.Role;
    const G = oldUser.client.guilds.cache.get(Settings.Server.Id);
    const member = G.members.cache.get(newUser.id)
    const allahmesajyolluyo = member.guild.channels.cache.find(r => r.name === Settings.Tag.Log);
    const role = G.roles.cache.find(roleInfo => roleInfo.id === R)
    const guild = oldUser.client.guilds.cache.get(Settings.Server.Id);
    const ask = new MessageEmbed().setColor(Config.EmbedColor).setAuthor(guild.name, guild.iconURL({dynamic: true}))

    if (newUser.username !== oldUser.username) {
        if (oldUser.username.includes(T1) && !newUser.username.includes(T1)) {
            member.roles.set(Settings.Roles.Unregistered)
            member.roles.remove(R)  
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramızdan ayrıldı!
            \` ➜ \` Alınan tag: **${T1}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))
        }            
        else if (!oldUser.username.includes(T1) && newUser.username.includes(T1)) {
            member.roles.add(R)
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramıza katıldı!
            \` ➜ \` Alınan tag: **${T1}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))        }
    }

    if (newUser.username !== oldUser.username) {
        if (oldUser.username.includes(T2) && !newUser.username.includes(T2)) {
            member.roles.set(Settings.Roles.Unregistered)
            member.roles.remove(R)  
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramızdan ayrıldı!
            \` ➜ \` Alınan tag: **${T2}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))
        }

        else if (!oldUser.username.includes(T2) && newUser.username.includes(T2)) {
            member.roles.add(R)
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramıza katıldı!
            \` ➜ \` Alınan tag: **${T2}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))        }
    }

    if (newUser.username !== oldUser.username) {
        if (oldUser.username.includes(T3) && !newUser.username.includes(T3)) {
            member.roles.set(Settings.Roles.Unregistered)
            member.roles.remove(R)  
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramızdan ayrıldı!
            \` ➜ \` Alınan tag: **${T3}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))
        }            
        else if (!oldUser.username.includes(T3) && newUser.username.includes(T3)) {
            member.roles.add(R)
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramıza katıldı!
            \` ➜ \` Alınan tag: **${T3}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))        }
    }

    if (newUser.username !== oldUser.username) {
        if (oldUser.username.includes(T4) && !newUser.username.includes(T4)) {
            member.roles.set(Settings.Roles.Unregistered)
            member.roles.remove(R)  
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramızdan ayrıldı!
            \` ➜ \` Alınan tag: **${T4}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))
        }
        else if (!oldUser.username.includes(T4) && newUser.username.includes(T4)) {
            member.roles.add(R)
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramıza katıldı!
            \` ➜ \` Alınan tag: **${T4}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))        }
    }

    if (newUser.username !== oldUser.username) {
        if (oldUser.username.includes(T5) && !newUser.username.includes(T5)) {
            member.roles.set(Settings.Roles.Unregistered)
            member.roles.remove(R)  
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramızdan ayrıldı!
            \` ➜ \` Alınan tag: **${T5}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))
        }            
        else if (!oldUser.username.includes(T5) && newUser.username.includes(T5)) {
            member.roles.add(R)
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramıza katıldı!
            \` ➜ \` Alınan tag: **${T5}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))        }
    }

    if (newUser.username !== oldUser.username) {
        if (oldUser.username.includes(T6) && !newUser.username.includes(T6)) {
            member.roles.set(Settings.Roles.Unregistered)
            member.roles.remove(R)  
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramızdan ayrıldı!
            \` ➜ \` Alınan tag: **${T6}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))
        }            
        else if (!oldUser.username.includes(T6) && newUser.username.includes(T6)) {
            member.roles.add(R)
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramıza katıldı!
            \` ➜ \` Alınan tag: **${T6}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))
                }
    }

    
    
    if (newUser.discriminator !== oldUser.discriminator) {
        if (oldUser.discriminator == Disc && newUser.discriminator !== Disc) {
            member.roles.set(Settings.Roles.Unregistered)
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramızdan ayrıldı!
            \` ➜ \` Alınan tag: **${Disc}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))
        } else if (oldUser.discriminator !== Disc && newUser.discriminator == Disc) {
            member.roles.add(R)
            allahmesajyolluyo.send(`${newUser} [\`${newUser.id}\`] `,ask.setDescription(`${newUser} Adlı üye <t:${Math.floor(Date.now() / 1000)}:R> tagımızı ismine alarak aramıza katıldı!
            \` ➜ \` Alınan tag: **#${Disc}**
            \` ➜ \` İsim değişikliliği: (**${oldUser.tag} => ${newUser.tag}**)`))
                }
    }  
}
  module.exports.config = {
    Event: "userUpdate"
}