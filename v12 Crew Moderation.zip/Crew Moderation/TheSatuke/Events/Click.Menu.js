const Settings = require("../Configuration/Settings.json");
const client = global.Client;
const { Client, Discord, MessageEmbed } = require("discord.js");
const moment = require("moment");
const disbut = require('discord-buttons');
const burclar = { "931658642955075604": Settings.Burc.Yengec, "931657544756248606": Settings.Burc.Aslan, "931658863923593297": Settings.Burc.Akrep, "931658464512598056": Settings.Burc.Oğlak, "931657587886264340": Settings.Burc.Balık, "931658178482012201": Settings.Burc.Başak, "931658397860892672": Settings.Burc.Kova, "931658529314603008": Settings.Burc.Terazi, "931658575951048714": Settings.Burc.Yay, "931658251181887508": Settings.Burc.Koç, "931658687028789289": Settings.Burc.İkizler, "931659095629529168": Settings.Burc.Boğa};
const renkler = {"🥥": Settings.Colors.White, "🍓": Settings.Colors.Red, "🍏": Settings.Colors.Green, "🍋": Settings.Colors.Yellow, "💙": Settings.Colors.Blue, "🍇": Settings.Colors.Purple};
const ilişki = {"💍": Settings.Lovers.Lovers, "💔": Settings.Lovers.Alone, "🖤": Settings.Lovers.NoSevgili}; 
const oyunlar = {"880606175274598461": Settings.Game.CSGO, "880606175761145906": Settings.Game.Lol,"880606175387873281": Settings.Game.Valorant, "880606175408824321": Settings.Game.GtaV, "880606175178153994": Settings.Game.Pubg, "880606175488540693": Settings.Game.Fortnite,};

moment.locale("tr");
      module.exports = (menu) => {

        if (menu.id == "burc") {
             menu.reply.think(true);
             menu.reply.edit("Rollerin güncellendi!");
            let add = [];
            let remove = [];
            let allRemove = [];
            let roller = burclar;
            for (const rol in roller) {
              let sonuc = roller[rol];
              allRemove.push(sonuc);
              if (menu.values.includes(sonuc)) {
               menu.reply.edit(`Başarılı bir şekilde <@&${sonuc}> rolü üzerinize eklendi!`);
                add.push(sonuc);
              } else {
                remove.push(sonuc);
              };
            };
            if (!menu.values.some(value => value === "allDelete")) {
              if (remove.length > 0) {
                 menu.clicker.member.roles.remove(remove);
        
              };
               menu.clicker.member.roles.add(add);
            
      
            } else {
               menu.clicker.member.roles.remove(allRemove);
             
      
            };
            };
      
        if (menu.id == "oyun") {
           menu.reply.think(true);
           menu.reply.edit("Rollerin güncellendi!");
          let add = [];
          let remove = [];
          let allRemove = [];
          let roller = oyunlar;
          for (const rol in roller) {
            let sonuc = roller[rol];
            allRemove.push(sonuc);
            if (menu.values.includes(sonuc)) {
                
               menu.reply.edit(`Başarılı bir şekilde <@&${sonuc}> rolü üzerinize eklendi!`);
              add.push(sonuc);
            } else {
              remove.push(sonuc);
            };
          };
          if (!menu.values.some(value => value === "allDelete")) {
            if (remove.length > 0) {
               menu.clicker.member.roles.remove(remove);
            };
             menu.clicker.member.roles.add(add);
             menu.clicker.member.roles.add(sonuc);
          } else {
             menu.clicker.member.roles.remove(allRemove);
      
          };
        };
        if (menu.id == "renk") {
           menu.reply.think(true);
          if (!menu.clicker.member.roles.cache.get(Settings.Roles.BoosterRole) && !menu.clicker.member.roles.cache.get(Settings.Tag.Role)) return  menu.reply.edit("Booster veya taglı üye olman gerek!");;
           menu.reply.edit("Rollerin güncellendi!");
          let add = [];
          let remove = [];
          let allRemove = [];
          let roller = renkler;
          for (const rol in roller) {
      
            let sonuc = roller[rol];  
      
            allRemove.push(sonuc);
            if (menu.values.includes(sonuc)) {    
               menu.reply.edit(`Başarılı bir şekilde <@&${sonuc}> rolü üzerinize eklendi!`);
      
              add.push(sonuc);
            } else {
              remove.push(sonuc);
      
            };
          };
          if (!menu.values.some(value => value === "allDelete")) {
            if (remove.length > 0) {
               menu.clicker.member.roles.remove(remove);
            };
             menu.clicker.member.roles.add(add);
          } else {
             menu.clicker.member.roles.remove(allRemove);
      
          };
        };
        if (menu.id == "diger") {
           menu.reply.think(true);
           menu.reply.edit("Rollerin güncellendi!");
          let add = [];
          let remove = [];
          let allRemove = [];
          let roller = ilişki;
          for (const rol in roller) {
            let sonuc = ilişki[rol];
            allRemove.push(sonuc);
            if (menu.values.includes(sonuc)) {
                
               menu.reply.edit(`Başarılı bir şekilde <@&${sonuc}> rolü üzerinize eklendi!`);
              add.push(sonuc);
            } else {
              remove.push(sonuc);
            };
          };
          if (!menu.values.some(value => value === "allDelete")) {
            if (remove.length > 0) {
               menu.clicker.member.roles.remove(remove);
             
      
            };
             menu.clicker.member.roles.add(add);
          } else {
             menu.clicker.member.roles.remove(allRemove);
          };
        };
      
      
    }
    
module.exports.config = {
    Event: "clickButton"
};
