
const client = global.Client;
const { Client, Discord, MessageEmbed } = require("discord.js");
const Settings = require("../Configuration/Settings.json");
const moment = require("moment");
const bannedTag = require("../Models/Database/Disabledtag");
require("moment-duration-format")
moment.locale("tr");

module.exports = member => {
    let satukeallah = member.guild.channels.cache.find(r => r.name === Settings.Server.WelcomeChannel);
    let championallah = member.guild.channels.cache.find(r => r.name === "champion");
    championallah.send(`${member}`).catch().then(message => { message.delete({ timeout: 1000}) });
 /*
    let Forceban = Forcebans.findOne({ _id: member.id });
    if(Forceban) { member.ban({ reason: 'Forceban tarafından yasaklandı.' })
    return member.guild.channels.cache.get(satukeallah).send(`${member} isimli üye sunucumuza katıldı, fakat Kalkmazban sistemi ile yasaklandığından dolayı sunucumuzda tekrar yasaklandı.`) };
 */

    if (member.user.bot) return member.roles.add(Settings.Roles.BotRoles);  
    if (Date.now() - member.user.createdTimestamp < 1000 * 60 * 60 * 24 * 7) {
    member.setNickname("• Şüpheli Hesap").catch();
    member.setRoles(Settings.Roles.Süpheli);
    satukeallah.send(`${Settings.emojiler.iptal} ${member} (\`${member.id}\`) Adlı kullanıcının hesabı yeni açıldığı için jaile atıldı.`)
    }
    else { 
        let user = client.users.cache.get(member.id);
        const kurulus = new Date().getTime() - user.createdAt.getTime();
        var kontrol;
        if (kurulus < 604800) kontrol = Settings.emojiler.iptal;
        if (kurulus > 604800) kontrol = Settings.emojiler.tik;
        member.roles.add(Settings.Roles.Unregistered);
        moment.locale("tr");
        satukeallah.send(`${Settings.emojiler.tag} ${member} **Champion #1949** Adlı Ekibimize hoş geldin, seninle beraber sunucumuz **${member.guild.memberCount}** üye sayısına ulaştı!
        
        Hesabın **<t:${Math.floor(member.user.createdTimestamp / 1000)}:D>** tarihinde oluşturulmuş ${kontrol}
        
        Unutma sunucu kurallarımız <#${Settings.Server.RulesChannel}> kanalında belirtilmiştir, Unutma sunucu içerisinde ki ceza işlemlerin kuralları okuduğunu varsayarak gerçekleştirilecek!`)                 
    }
    
}

module.exports.config = {
    Event: "guildMemberAdd"
}

/*
    bannedTag.findOne({ guildID: Settings.Server.Id }, async ( err, res) => {
    res.taglar.forEach(async x => {
    if(res.taglar.some(x => member.user.username.includes(x))) { 
    member.roles.set(Settings.Penals.Jail.Role)
    member.setNickname("Yasaklı Tag")
    if (Config.dmMessage) member.send(`${member.guild.name} adlı sunucumuza olan erişiminiz engellendi! Sunucumuzda yasaklı olan bir simgeyi (${x}) isminizde taşımanızdan dolayıdır. Sunucuya erişim sağlamak için simgeyi (${x}) isminizden çıkartmanız gerekmektedir.\n\nSimgeyi (${x}) isminizden kaldırmanıza rağmen üstünüzde halen Yasaklı Tag rolü varsa sunucudan gir çık yapabilirsiniz veya sağ tarafta bulunan yetkililer ile iletişim kurabilirsiniz. **-Yönetim**\n\n__Sunucu Tagımız__\n**${conf.tag}**`).catch(() => {});}})})
*/
