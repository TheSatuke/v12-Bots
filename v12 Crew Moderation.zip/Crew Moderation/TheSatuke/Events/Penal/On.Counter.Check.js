const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");
const pm = require("../../Managers/Penal.Manager");
const Penal = require("../../Models/Database/Penal");
const client = global.Client;
const botVoiceChannel = client.channels.cache.get(Config.VoiceChannel);
const guildInvites = new Map();

module.exports = async() => {

client.user.setStatus('online');
client.user.setActivity(Config.Status, { type: 'WATCHING' })
if (botVoiceChannel) botVoiceChannel.join().catch(err => console.error("Bot ses kanalına bağlanamadı!"));

}


module.exports.config = {
    Event: "ready"
}
