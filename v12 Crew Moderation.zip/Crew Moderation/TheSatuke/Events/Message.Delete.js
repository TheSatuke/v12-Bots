const Settings = require("../Configuration/Settings.json");
const Config = require("../Configuration/Config.json");
const { Client, Discord, MessageEmbed } = require("discord.js");
const db = require("quick.db");

module.exports = (message) => {
   let allah = message.guild.channels.cache.get(Settings.Server.messageLog) 
   if(allah) {
   if (message.author.bot || message.channel.type == "dm") return;
   const messageDelete = new MessageEmbed().setTimestamp()
   if (message.attachments.first()) {
    allah.send(messageDelete.setAuthor(`${message.author.tag} Fotoğraf Silindi`, message.author.avatarURL()).setDescription(`<#${message.channel.id}> kanalında <@!${message.author.id}> tarafından bir fotoğraf silindi. 

Silinen fotoğraf:`).setImage(message.attachments.first().proxyURL).setColor(Config.EmbedColor).setFooter(Config.Status))} 
else {

  allah.send(messageDelete.setAuthor(`${message.author.tag} Mesaj Silindi`, message.author.avatarURL())
.setDescription(`<#${message.channel.id}> kanalında <@!${message.author.id}> tarafından bir mesaj silindi. \n\n\` ➥ \` Mesaj İçeriği: **${message.content}**`).setColor(Config.EmbedColor).setFooter(Config.Status));}}
   
if (message.channel.type === "dm" || !message.guild || message.author.bot) return;
db.set(`snipe.${message.guild.id}.${message.channel.id}`, { yazar: message.author.id, yazilmaTarihi: message.createdTimestamp, silinmeTarihi: Date.now(), dosya: message.attachments.first() ? true : false });
if (message.content) db.set(`snipe.${message.guild.id}.${message.channel.id}.icerik`, message.content);

}
module.exports.config = {
    Event: "messageDelete"
}