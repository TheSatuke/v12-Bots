const { Discord, Client, MessageEmbed } = require('discord.js');
const client = global.client = new Client({fetchAllMembers: true});
const guildInvites = new Map();
const Config = require("./Configuration/Config.json");
const Settings = require("./Configuration/Settings.json");
const moment = require("moment");
const mongoose = require('mongoose');
const Database = require("./Models/Database/Invite");
moment.locale("tr");
const Events = require("./Managers/Event.Manager");
Events.addEvent("Afk")
Events.addEvent("Message");
Events.addEvent("Command.Handler");
Events.addEvent("Click.Menu");
Events.addEvent("Guild.Member.Add");
Events.addEvent("Timer.js");
Events.addEvent("Penal/On.Member.Update");
Events.addEvent("Penal/On.Ready");
Events.addEvent("Penal/On.Voice.State.Update");
Events.addEvent("Penal/On.Counter.Check");
Events.addEvent("Guild.Member.Update");
Events.addEvent("Message.Delete");
Events.addEvent("Click.Button");
Events.addEvent("Message.Update");
Events.addEvent("Voice.Update");
Events.addEvent("Tag/Crew.User.Update");

require("./Utils/Helper");
require("./Utils/Patch");
require("./Functions/Client.Login")
require("discord-buttons")(client)
require("./Managers/Counter.Manager");
