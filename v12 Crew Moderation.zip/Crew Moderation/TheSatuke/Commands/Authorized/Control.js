const { Message, Client, MessageEmbed, Discord, Application, MessageFlags} = require("discord.js");
const Settings = require("../../Configuration/Settings.json");
const disbut = require("discord-buttons");
const moment = require("moment");
require("moment-duration-format");const Config = require("../../Configuration/Config.json");

/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */

module.exports.execute = async (client, message, args) => {
    if(!message.member.hasPermission("ADMINISTRATOR") && !Settings.Roles.Owner.some(authRole => message.member.roles.cache.has(authRole)))
    return message.lineReply(`${Settings.emojiler.iptal} Bu komudu kullanmaya yetkin yetmiyor :c`).then(x => x.delete({timeout: 7500}));
    
    let member = message.guild.member(message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.author);
    
    
       let Tagli = message.guild.members.cache.filter(s => s.user.username.includes("✦") && !s.roles.cache.has(Settings.Tag.Role))
       let EtCekilis = message.guild.members.cache.filter(member => !member.roles.cache.has(Settings.Roles.Etkinlik) || !member.roles.cache.has(Settings.Roles.Etkinlik)).size;
       let UnregMember = message.guild.members.cache.filter(m => m.roles.cache.filter(r => r.id !== message.guild.id).size == 0)
       let EtkinlikCekiliss = new disbut.MessageButton().setStyle('red').setLabel('Etkinlik/Çekiliş Rol Dağıt').setID('EtkinlikCekilis')
       let Taglı = new disbut.MessageButton().setStyle('green').setLabel('Tag Rol Dağıt').setID('Taglı')
       let Unregister = new disbut.MessageButton().setStyle('blurple').setLabel('Kayıtsız Rol Dağıt').setID('kayıtsızdagit')
       let Embed = new MessageEmbed().setDescription(`${message.member.toString()} Sunucunun rol kontrol tablosu aşşağıda!
 \`•\` Etkinlik/Çekiliş: **${EtCekilis}**
 \`•\` Taglı: **${Tagli.size}**
 \`•\` Kayıtsız: **${UnregMember.size}**`).setAuthor(message.author.tag, message.author.avatarURL()).setColor(Config.EmbedColor).setTimestamp().setThumbnail(message.author.displayAvatarURL({ dynamic: true, size: 2048 }))
    
    
let msg = await message.channel.send({ buttons : [EtkinlikCekiliss,Taglı,Unregister], embed: Embed})    
var filter = (button) => button.clicker.user.id === message.author.id;      
let collector = await msg.createButtonCollector(filter, { time: 30000 })
   
collector.on("collect", async (button) => {
   
if (button.id === 'EtkinlikCekilis') {    
let Et_Cek = message.guild.members.cache.filter(member => !member.roles.cache.has(Settings.Roles.Etkinlik) || !member.roles.cache.has(Settings.Roles.Cekilis))
button.reply.send(`\`•\` Etkinlik/Çekiliş rolü olmayan **${Et_Cek.size}** kullanıcıya rol vermeye başladım!`)
message.guild.members.cache.filter(member => !member.roles.cache.has(Settings.Roles.Etkinlik) || !member.roles.cache.has(Settings.Roles.Cekilis)).map(x=> x.roles.add([Settings.Roles.Etkinlik, Settings.Roles.Cekilis]));
}
   
   
if (button.id === 'Taglı') {    
let Taglis = message.guild.members.cache.filter(s => s.user.username.includes(Settings.Tag.Tag) && !s.roles.cache.has(Settings.Tag.Role))   
button.reply.send(`
${Settings.emojiler.tik} Rolü Verilecek Kişi Sayısı: **${Taglis.size}**
\`\`\`Tag Rolü verilen kullanıcılar;\`\`\`
${Taglis.map(x => x || "Rolü olmayan Kullanıcı bulunmamaktadır.")}`)
   
message.guild.members.cache.filter(s => s.user.username.includes(Settings.Tag.Tag) && !s.roles.cache.has(Settings.Tag.Role)).map(x=> x.roles.add(Settings.Tag.Role))                
}
   



if (button.id === 'kayıtsızdagit') {
let Members = message.guild.members.cache.filter(m => m.roles.cache.filter(r => r.id !== message.guild.id).size == 0)   
button.reply.send(`
${Settings.emojiler.tik} Sunucuda rolü bulunmayan kişilere **Kayıtsız** rolü verildi
\`\`\`Verilen Kullanıcı sayısı: ${Members.size}\`\`\``)
   
message.guild.members.cache.filter(m => m.roles.cache.filter(r => r.id !== message.guild.id).size == 0).map(x=> x.roles.add(Settings.Roles.Unregistered))
   
    }
   });
  }
   

module.exports.settings = {
    Commands: ["control", "kontrol"],
    Usage: "control",
    Description: "",
    Category: "Authorized",
    Activity: false
}