const Config = require("../../Configuration/Config.json");
const Settings = require("../../Configuration/Settings.json");
const moment = require("moment");
require("moment-duration-format")
moment.locale("tr")

const { Client, Message, Guild, MessageEmbed } = require("discord.js");
client = global.client;

/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */
 module.exports.execute = async (client, message, args) => {
  if(!message.member.hasPermission("ADMINISTRATOR") && !Settings.Roles.Owner.some(authRole => message.member.roles.cache.has(authRole)))
  return message.lineReply(`${Settings.emojiler.iptal} Bu komudu kullanmaya yetkin yetmiyor :c`).then(x => x.delete({timeout: 7500}));
    
      if (!args[0]) return message.lineReply(`Kullanımı: !r al/ver Kullanıcı Rol`)
      if (args[0] != "al") {
          if (args[0] != "ver") {
              return message.lineReply(`Kullanımı: !r al/ver Kullanıcı Rol`)
          }
      }
  
      if (!args[1]) return message.lineReply(`Bir üye etiketle ve tekrardan dene!`)
      let rMember = message.mentions.members.first() || message.guild.members.cache.get(args[1])
      if (!rMember) return message.lineReply(`Bir üye etiketle ve tekrardan dene!`)
  
      if (!args[2]) return message.lineReply(`Rolü belirtmelisin.`)
      let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2])
          if (!role) return message.lineReply(`Belirtmiş olduğun rolü bulamadım ! Düzgün bir rol etiketle veya ID belirtip tekrar dene.`)
          if (message.member.roles.highest.rawPosition <= role.rawPosition) return message.lineReply(` Kendi rolünden yüksek veya eşit bir rolle işlem yapamazsın.`)
         
  
          if (args[0] == "al") {
            if (rMember.roles.cache.has(role.id)) {
              rMember.roles.remove(role.id)
              message.lineReply(`${rMember} Kişisinden ${role} rolünü aldım.`)
            } else {
              message.lineReply(`${rMember} Kişisinde ${role} rolü mevcut değil.`)
            }
        }
        if (args[0] == "ver") {
            if (!rMember.roles.cache.has(role.id)) {
              rMember.roles.add(role.id)
              message.lineReply(`${rMember} Kişisine ${role} rolünü ekledim.`)
            } else {
              message.lineReply(`${rMember} Kişisinde ${role} rolü zaten mevcut.`)
            }
        }
     }
  

module.exports.settings = {
    Commands: ["r","rol"],
    Usage: "r ver/al <user/id>",
    Activity: true,
    permLevel: 7,   
    Category: "Authorized",
    cooldown: 10000
}