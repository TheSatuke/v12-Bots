const { Message, Client, MessageEmbed } = require("discord.js");
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");
const db = require('quick.db');
const moment = require('moment');
require('moment-duration-format');


/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */
 module.exports.execute = async (client, message, args) => {

var S = new MessageEmbed().setAuthor(message.member.displayName, message.author.avatarURL({dynamic: true})).setColor('#2F3136')
if (message.member.roles.cache.has(Settings.Roles.Commanders) || message.member.roles.highest.position >= message.guild.roles.cache.get(Settings.Roles.Commanders).position) {
let mesaj = db.get(`snipe.${message.guild.id}.${message.channel.id}`);
if (!mesaj) { return message.lineReply(S.setDescription(`Bu kanalda silinmiş bir mesaj bulunmamakta.`)).then(msg => msg.delete({timeout: 5000}))}
            
if (mesaj.icerik) {
let mesajYazari = await message.guild.members.cache.get(mesaj.yazar);
return message.lineReply(S.setDescription(`
\` ➜ \` Mesaj Sahibi: ${mesajYazari ? mesajYazari : mesajYazari.tag} (**${mesajYazari.id}**)
\` ➜ \` Mesajın Yazılma Tarihi: **${moment.duration(Date.now() - mesaj.yazilmaTarihi).format("D [gün], H [saat], m [dakika], s [saniye]")}**
\` ➜ \` Mesajın Silinme Tarihi: **${moment.duration(Date.now() - mesaj.silinmeTarihi).format("D [gün], H [saat], m [dakika], s [saniye]")}** 
     
\` ➜ \` Mesaj İçeriği: **${mesaj.dosya ? "Silinen mesaj bir fotoğraf." : mesaj.icerik}**`))
      }
      } else {
        message.delete({timeout: 5000})
        return message.lineReply(hembed.setDescription(`Bu komutu kullanmak için yetkin yetersiz.`)).then(msg => msg.delete({timeout: 5000}))
      }
 }
module.exports.settings = {
  Commands: ["snipe"],
  Usage: "snipe",
  Description: "Toplantı esnasında toplantıda olan kişilere katıldı rolü dağıtır.",
  Category: "Authorized",
  Activity: true
}