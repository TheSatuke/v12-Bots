const { MessageEmbed } = require("discord.js");
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");


module.exports.execute = async (client, message, args) => {
if(!message.member.roles.cache.get("996461887225090179") && !message.member.hasPermission('ADMINISTRATOR'))  return message.lineReply(`${Settings.emojiler.iptal} ${Text.YetkinYetmiyor}`);
  var member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
  var embed = new MessageEmbed().setColor(Config.EmbedColor).setFooter(Config.Footer).setTimestamp();
  if (!member) return message.lineReply(`${Settings.emojiler.iptal} Kayıt edilicek bir kullanıcı belirtmelisin. `).then(x => x.delete({ timeout: 5500 }));
  if (message.member.roles.highest.position <= member.roles.highest.position) return message.lineReply(`${Settings.emojiler.iptal} ${member} Bu işlemi gerçekleştiremiyorum (üst/aynı) yetkidesiniz`).then(x => x.delete({ timeout: 5500 }));
    if (args[1]) {
      var newName;
      args = args.filter(a => a.trim().length).slice(1);
      if (Config.name_age) {
        let name = args.filter(a => isNaN(a)).map(a => a.charAt(0).replace("i", "İ").toUpperCase() + a.slice(1)).join(" ");
        let age = args.find(a => !isNaN(a)) || undefined;
        if (!name) return message.lineReply(`${Settings.emojiler.iptal} Kayıt işlemini gerçekleştirmek için geçerli bir isim ve yaş belirtmelisin.`).then(x => x.delete({ timeout: 10000 }));
        newName = `${name} Champion`;
      };
      await member.setNickname(newName).catch(err => { return undefined; });
    };
    message.react(Settings.emojiler.onayID);
      if (Settings.Roles.Unregistered.some(r => member.roles.cache.has(r))) {
  /*await teyitci.findByIdAndUpdate(message.author.id, { $inc: { teyitler: 1 } }, { upsert: true });
    await kayitlar.findByIdAndUpdate(member.id, { $push: { kayitlar: [{ isim: member.displayName, roller: Settings.Roles.Man, tarih: Date.now() }] } }, { upsert: true });
  */
};
  await member.roles.set(member.roles.cache.map(r => r.id).filter(r => !Settings.Roles.Unregistered.includes(r) && !Settings.Roles.Woman.includes(r)).concat(Settings.Roles.Man)).catch(err => { return undefined; });
  let kanal = member.guild.channels.cache.find(r => r.name === Settings.Server.ChatChannel);
  kanal.send(`${Settings.emojiler.hello} ${member} Aramıza yeni birisi katıldı, Hoşgeldin!`).then(x => x.delete({ timeout: 15000 }));  
};

module.exports.settings = {
    Commands: ["e", "boy", "man","E","Erkek"],
    Usage: "Erkek",
    Description: "",
    Category: "Registerian",
    Activity: true
}
