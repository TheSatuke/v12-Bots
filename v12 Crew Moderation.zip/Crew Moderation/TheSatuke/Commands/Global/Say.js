const { MessageEmbed } = require('discord.js')
const Config = require("../../Configuration/Config.json");
const Settings = require("../../Configuration/Settings.json");

/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */

module.exports.execute = async (client, message, args) => {
if(!message.member.hasPermission("ADMINISTRATOR") && !Settings.Roles.Commanders.some(authRole => message.member.roles.cache.has(authRole)))
return message.lineReply(`${Settings.emojiler.iptal} Bu komudu kullanmaya yetkin yetmiyor :c`).then(x => x.delete({timeout: 7500}));

    const TopMember = message.guild.memberCount;
    const BotVoice = message.guild.channels.cache.filter(c => c.type === "voice").map(c => c.members && c.members.filter(x => x.user.bot).size).reduce((a,b) => a+b) || 0;
    const OnlineUser = message.guild.members.cache.filter(off => off.presence.status !== 'offline').size
    const Voice = message.guild.members.cache.filter(s => s.voice.channel).size;
    const sesli = message.guild.channels.cache.filter(channel => channel.type == "voice").map(channel => channel.members.size).reduce((a, b) => a + b);
    var T_1 = message.guild.members.cache.filter(s => !s.bot).filter(member => member.user.username.includes(`Champion`)).size;
    var T_2 = message.guild.members.cache.filter(s => !s.bot).filter(member => member.user.username.includes(`champion`)).size;
    var T_3 = message.guild.members.cache.filter(s => !s.bot).filter(member => member.user.username.includes(`Champ`)).size;
    var T_4 = message.guild.members.cache.filter(s => !s.bot).filter(member => member.user.username.includes(`champ`)).size;
    var T_5 = message.guild.members.cache.filter(s => !s.bot).filter(member => member.user.username.includes(`1949`)).size;
    var T_7 = message.guild.members.cache.filter(s => !s.bot).filter(member => member.user.username.includes(`'`)).size;
    var D =  message.guild.members.cache.filter(s => !s.bot).filter(member => member.user.discriminator == "1949").size;
    var T = T_1 + T_2 + T_3 + T_4 + T_5 + T_7 + D;
    
    const Embed = new MessageEmbed()
.setColor(Config.EmbedColor)
.setAuthor(message.guild.name, message.guild.iconURL({dynamic: true}))
.setDescription(`
\`•\` Sesli sohbetlerde toplam **${Voice}** kişi var.
\`•\` Sunucumuzda şuanda toplam **${TopMember}** üye bulunmakta. (**${OnlineUser} aktif**)
\`•\` Tagımızı alarak ailemize destek olan **${T_1 + T_2 + T_3 + T_4 + T_5 + T_7 + D}** kişi bulunmaktadır.
\`•\` Toplam **${message.guild.premiumSubscriptionCount}** adet boost basılmış (**${message.guild.premiumTier}.** Seviye)`)
message.lineReply(Embed)}

module.exports.settings = {
    Commands: ["say","SAY","Say"],
    Usage: "say",
    Description: "Sunucunun Güncel Verilerini Atar.",
    Category: "Global",
    Activity: true
}
