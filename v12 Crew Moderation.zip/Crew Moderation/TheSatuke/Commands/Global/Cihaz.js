const { Message, Client, MessageEmbed, Discord, Application, MessageFlags} = require("discord.js");

module.exports.execute = async (client, message, args) => {
let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
const Embed3 = new MessageEmbed()
.setColor("RANDOM")
.setAuthor(message.member.displayName, message.author.avatarURL({dynamic: true}))
.setDescription(`Bir kullanıcı etiketle.`)

if (!member) return message.lineReply(Embed3).then(qwe => qwe.delete({ timeout: 5000 }));

const Embed2 = new MessageEmbed()
.setColor("RANDOM")
.setAuthor(message.member.displayName, message.author.avatarURL({dynamic: true}))
.setDescription(`${member} kullanıcısı offline olduğu için cihazına bakılamıyor`)


if (member.user.presence.status == "offline") return message.lineReply(Embed2)
let cihaz = ""
let obje = Object.keys(member.user.presence.clientStatus)
if (obje[0] == "mobile") cihaz = "Telefon"
if (obje[0] == "desktop") cihaz = "Masaüstü Uygulama"
if (obje[0] == "web") cihaz = "İnternet Tarayıcısı"

const Embed = new MessageEmbed()
.setColor("RANDOM")
.setAuthor(message.member.displayName, message.author.avatarURL({dynamic: true}))
.setDescription(`${member} kullanıcısı \`${cihaz}\` cihazından bağlanıyor.`)
message.lineReply(Embed)}

module.exports.settings = {
    Commands: ["cihaz"],
    Usage: "cihaz <user/id>",
    Description: "",
    Category: "Global",
    Activity: true
}