const penals = require("../../Models/Database/Penal");
const moment = require("moment")
moment.locale("tr");

require("moment-duration-format");
const { MessageButton,MessageActionRow } = require('discord-buttons');


module.exports.execute = async (client, message, args) => {

    if (!message.member.hasPermission('ADMINISTRATOR'))
{
message.lineReply("Bu işleme yetkin yetmiyor :c").then(x=>x.delete({timeout: 5000}))
}
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
     
    var DeleteName = new MessageButton()
    .setLabel("İsim Sıfırla")
    .setID("isim_sıfırla")
    .setStyle("blurple")

    var DeletePenalty = new MessageButton()
    .setLabel("Ceza Puan Sıfırla")
    .setID("cezapuan_sıfırla")
    .setStyle("green")

    var DeletePenal = new MessageButton()
    .setLabel("Sicil Sıfırla")
    .setID("sicil_sıfırla")
    .setStyle("red")

    var Iptal = new MessageButton()
    .setLabel("İptal")
    .setID("iptal_button")
    .setStyle("gray")
    .setEmoji("909485171240218634")

    const row = new MessageActionRow()
    .addComponents(DeleteName, DeletePenalty, DeletePenal, Iptal)

let satuke = (`
${message.author} Sıfırlama paneline hos geldin knk.
\`\`\`diff
- İsim Sıfırlama
- Ceza Puan Sıfırlama
- Sicil Sıfırlama
\`\`\`
${member.toString()} üyesine ait sıfırlamak istediğin veriyi aşağıdaki butonlar yardımıyla sıfırlayabilirsiniz.
`)
  

   

    let msg = await message.channel.send(satuke, { components: [row] });
    var filter = (button) => button.clicker.user.id === message.author.id;
   
    let collector = await msg.createButtonCollector(filter, { time: 99999999 })
    collector.on("collect", async (button) => {

      if(button.id === "isim_sıfırla") 
      {
    
    }      
    
  if(button.id === "cezapuan_sıfırla") {
    message.reply("Bakımda");
}      

 if(button.id === "sicil_sıfırla"){
    message.reply("Bakımda");
}      


 if(button.id === "iptal_button"){
    message.reply("Bakımda");
}      



  })
  }

module.exports.settings = {
    Commands: ["sıfırla"],
    Usage: "sıfırla",
    Description: "",
    Category: "Delete",
    Activity: true
}
