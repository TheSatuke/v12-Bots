const cezapuan = require("../../Models/Database/CezaPoint");
const moment = require("moment")
const Settings = require("../../Configuration/Settings.json");
const { MessageEmbed } = require("discord.js")
moment.locale("tr");

module.exports.execute = async (client, message, args) => {
    if (!message.member.hasPermission('ADMINISTRATOR'))
    {
    message.lineReply("Bu işleme yetkin yetmiyor :c").then(x=>x.delete({timeout: 5000}))
    return;
    }
    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0])
    if(!member)
    {
    message.lineReply("Ceza puanını sıfırlamamı istediğin kişiyi etiketle!").then(x=>x.delete({timeout:5000}))
    return;
    }
    const cezapuanData = await cezapuan.findOne({userID: member.user.id, guildID: message.guild.id})
    if(!cezapuanData)
    {
    message.lineReply(`${member} kişisinin ceza puanı zaten yok!`)
    return;
    }
    message.lineReply(`${member} adlı kullanıcının __Ceza Puanı__ **<t:${Math.floor(Date.now() / 1000)}:R>** temizlendi!`)
    await cezapuan.deleteMany({userID: member.user.id, guildID: message.guild.id})
    const allahmesajyolluyo = member.guild.channels.cache.find(r => r.name === "delete-log");
    const guild = client.guilds.cache.get(Settings.Server.Id);
    const ask = new MessageEmbed().setAuthor(message.member.displayName, message.author.avatarURL({dynamic: true})).setColor('#2F3136')
    allahmesajyolluyo.send(ask.setDescription(`${member} adlı kullanıcının **Ceza Puanı** <t:${Math.floor(Date.now() / 1000)}:R> temizlendi`))
    }
    
module.exports.settings = {
    Commands: ["cezapuansil", "pointdelete","cezapuansil"],
    Usage: "cezapuansil",
    Description: "",
    Category: "Delete",
    Activity: true
}
