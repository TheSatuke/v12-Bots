const { Message, Client, Application, MessageFlags} = require("discord.js");
const Discord = require("discord.js");
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");
const moment = require("moment");
const ms = require("ms")
const cezapuan = require("../../Models/Database/CezaPoint")

const Helper = require("../../Utils/Helper");
const Penal = require("../../Models/Database/Penal");
const PM = require("../../Managers/Penal.Manager");
require("moment-timezone");
require("moment-duration-format")
moment.locale("tr")

/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */
module.exports.execute = async (client, message, args) => {
    if(!message.member.hasPermission("ADMINISTRATOR") && !Settings.Roles.Commander.some(authRole => message.member.roles.cache.has(authRole))) return message.lineReply(`${Settings.emojiler.iptal} Bu komudu kullanmaya yetkin yetmiyor c`);

    let victim = message.mentions.users.first() || client.users.cache.get(args[0]) || await Helper.GetUser(args[0]);
    if(!victim) return message.reply(`${Settings.emojiler.iptal} Uyarmak istediğin bir kullanıcıyı belirtmelisin.`);
    
    let reason = args.splice(1).join(" ");
    if(!reason) return message.reply(`${Settings.emojiler.iptal} Geçerli bir uyarı sebebi girmelisin.`);

    let member = await message.guild.getMember(victim.id);
    if(member && member.roles.highest.position >= message.member.roles.highest.position) return message.reply("senin rolünden üstte ya da aynı roldeki birisine uyarı veremezsin.")

    let document = await PM.addPenal(victim.id, message.author.id, PM.Types.WARN, reason);
    message.lineReply(`${victim}, ${message.author} tarafından **"${reason}"** sebebiyle uyarıldı, Ceza Numarası -  (\`#${document.Id}\`) ${Settings.emojiler.tik}`)
    let pointlogKanali = client.channels.cache.find(a => a.name == Settings.Server.cezaPointLog)
    await cezapuan.findOneAndUpdate({ guildID: message.guild.id, userID: member.user.id }, { $inc: { cezapuan: 15 } }, { upsert: true });
    const cezapuanData = await cezapuan.findOne({ guildID: message.guild.id, userID: member.user.id });
    if(pointlogKanali) pointlogKanali.send(`${member} Kullanıcısı **#${document.Id}** Id'li cezayı alarak toplam **${cezapuanData ? cezapuanData.cezapuan : 0}** ceza puanına ulaştı!`);
    

    let logKanali = client.channels.cache.find(a => a.name == "warn-log")
    const embed = new Discord.MessageEmbed()
    .setDescription(`${victim} Kullanıcısı, ${message.author} tarafından **Warn** adlı ceza ile uyarıldı.`)
    .addField(`Ceza Numarası`,`${document.Id}`, true)
    .addField(`Ceza Sebebi`,`${reason}`, true)
    .addField(`Yetkili`,`${message.author}`, true)
    .addField(`Kullanıcı`,`${victim}`, true)
    .setColor(Config.EmbedColor).setAuthor(message.member.displayName, message.author.avatarURL({ dynamic: true })).setFooter(Config.Status)
    logKanali.send(embed);
    //client.channels.cache.get(Log.Log.MuteLog).send(embed)
    


//    message.guild.log(message.author, victim, document, Settings.Penals.Warn.Log);
}

module.exports.settings = {
    Commands: ["warn", "uyarı", "uyar"],
    Usage: "warn <@user|id> [reason]",
    Description: "Bahsettiğin kişiyi sunucuda uyarırsın.",
    Category: "Penal",
    Activity: true
}