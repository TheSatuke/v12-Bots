const Discord = require('discord.js');
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");
const afk = require("../../Models/Database/Afk");
  
module.exports.execute = async (client, message, args) => {
    if(!message.member.hasPermission("ADMINISTRATOR") && !Settings.Roles.Commanders.some(authRole => message.member.roles.cache.has(authRole)))
    return message.lineReply(`${Settings.emojiler.iptal} Bu komudu kullanmaya yetkin yetmiyor :c`).then(x => x.delete({timeout: 7500}));

    if(!message.guild.vanityURLCode) return message.lineReply("Sunucuda bir özel url yok.");
    const url = await message.guild.fetchVanityData();
    message.lineReply(`\`•\` discord.gg/${message.guild.vanityURLCode}
\`•\` Toplam kullanım: **${url.uses}**`)
} 
    
module.exports.settings = {
    Commands: ["link"],
    Usage: "url",
    Description: "",
    Category: "Advanced",
    Activity: true
}
