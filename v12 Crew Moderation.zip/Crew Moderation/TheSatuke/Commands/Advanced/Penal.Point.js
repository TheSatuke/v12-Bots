
const { Message, Client, MessageEmbed, Discord, Application, MessageFlags} = require("discord.js");
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");
const cezapuan = require("../../Models/Database/CezaPoint")
const ceza = require("../../Models/Database/Punitive")
const moment = require("moment");

/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */

moment.locale("tr");

module.exports.execute = async (client, message, args) => {

    if(!message.member.hasPermission("ADMINISTRATOR"))
    return message.lineReply(`${Settings.emojiler.iptal} Bu komudu kullanmaya yetkin yetmiyor :c`).then(x => x.delete({timeout: 7500}));

    const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.member;
    if (!member) { message.lineReply("Kullanıcı bulunamadı").then(x=>x.delete({timeout:5000}))
    message.react(red)
    return 
    }
    const cezapuanData = await cezapuan.findOne({ guildID: Settings.Server.Id, userID: member.user.id });
    message.lineReply(`${member} kişisinin toplamda **${cezapuanData ? cezapuanData.cezapuan : 0}** ceza puanı olarak gözükmekte!`)
    }


module.exports.settings = {
    Commands: ["cezapuan"],
    Usage: "cezapuan <id>",
    Description: "",
    Category: "Advanced",
    Activity: true
}
