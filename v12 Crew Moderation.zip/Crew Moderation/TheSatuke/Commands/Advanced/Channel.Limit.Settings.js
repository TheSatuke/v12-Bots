const { Message, Client, MessageEmbed, Discord, Application, MessageFlags} = require("discord.js");
const axios = require('axios')
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");

/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */

module.exports.execute = async (client, message, args) => {
    if(!message.member.hasPermission("ADMINISTRATOR") && !Settings.Roles.Owner.some(authRole => message.member.roles.cache.has(authRole)))
    return message.lineReply(`${Settings.emojiler.iptal} Bu komudu kullanmaya yetkin yetmiyor :c`).then(x => x.delete({timeout: 7500}));

    if (!message.guild) return;
    if (message.member.permissions.has(8)) {
        let sec = args[0];
        if (sec === "limit") {
            if (message.member.voice.channel) {
                const miktar = Number(args[1]);
                if (!miktar) return;
                if (miktar > 99) return;
                if (miktar < 0) return;
                client.channels.cache.get(message.member.voice.channel.id).edit({userLimit: miktar})
                message.lineReply(`Başarılı bir şekilde bulunduğun kanalın limitini \`${miktar}\` olarak değiştirdin.`);
            }
        };

}
}

module.exports.settings = {
    Commands: ["kanal"],
    Usage: "limit-ayarla",
    Activity: true,
    Category: "Advanced",
    cooldown: 10000
}