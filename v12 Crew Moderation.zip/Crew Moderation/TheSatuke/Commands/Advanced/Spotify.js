const Discord = require('discord.js');
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");
const afk = require("../../Models/Database/Afk");
const moment = require("moment");

  
module.exports.execute = async (client, message, args) => {

    let u = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
if (!u.presence.activities[1]) return message.channel.send("**Bu üyenin profilinde herhangi bir oynuyor aktivitesi yok.**").then(m => m.delete({ timeout: 5000 }));
if (u.presence.activities[1].name === "Spotify") {
  let isim = u.presence.activities[1].details;
  let soyleyen = u.presence.activities[1].state;
  let baslangicSaati = moment(u.presence.activities[1].timestamps.start).format("HH:mm:ss");
  let bitisSaati = moment(u.presence.activities[1].timestamps.end).format("HH:mm:ss");
  let albümİsmi = u.presence.activities[1].assets.largeText;
  let image = `https://i.scdn.co/image/${u.presence.activities[1].assets.largeImage.slice(8)}`;
  let URL = `https://open.spotify.com/track/${u.presence.activities[1].syncID}`;
  message.lineReply({
    embed: {
      color: "RANDOM",
      author: { name: `${isim}`, icon_url: image, url: URL },
      description: `\`•\` Şarkı Adı:  **${isim}**
      \`•\` Sanatçı: **${soyleyen}**
      \`•\` Albüm İsmi: **${albümİsmi}**
      \`•\` Şarkının Başlama Saati: **${baslangicSaati}**
      \`•\` Şarkının Bitiş Saati: **${bitisSaati}**`
    }
  });
} else {
  message.lineReply("**Bu üye spotify dinlemiyor.**");
};
}

    
module.exports.settings = {
    Commands: ["spotify"],
    Usage: "spotify <sebep>",
    Description: "",
    Category: "Advanced",
    Activity: true
}
