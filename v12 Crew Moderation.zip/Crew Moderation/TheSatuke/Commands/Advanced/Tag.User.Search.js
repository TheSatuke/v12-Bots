const { MessageEmbed } = require('discord.js');
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");


module.exports.execute = async (client, message, args) => {
    if(!message.member.hasPermission("ADMINISTRATOR") && !Settings.Perm.Owner.some(authRole => message.member.roles.cache.has(authRole))) 
    return message.lineReply(`${Settings.emojiler.iptal}`);

    var embed = new MessageEmbed().setAuthor(message.author.tag, message.author.avatarURL({dynamic: true})).setColor(Config.EmbedColor)
    let tag = "Champion"
    let tag2 = "Champ"
    let tag3 = "champ"
    let tag4 = "champion"
    let tag6 = "1949"
    let tag7 = "'"
    let etiket = "1949"

    let rol = Settings.Tag.Role;
    let taglilar = message.guild.members.cache.filter(s => s.user.username.includes(tag) && !s.roles.cache.has(rol))
    let taglilar2 = message.guild.members.cache.filter(s => s.user.username.includes(tag2) && !s.roles.cache.has(rol))
    let taglilar3 = message.guild.members.cache.filter(s => s.user.username.includes(tag3) && !s.roles.cache.has(rol))
    let taglilar4 = message.guild.members.cache.filter(s => s.user.username.includes(tag4) && !s.roles.cache.has(rol))
    let taglilar6 = message.guild.members.cache.filter(s => s.user.username.includes(tag6) && !s.roles.cache.has(rol))
    let taglilar7 = message.guild.members.cache.filter(s => s.user.username.includes(tag7) && !s.roles.cache.has(rol))
    let etiketliler = message.guild.members.cache.filter(s => s.user.discriminator.includes(etiket) && !s.roles.cache.has(rol))
    let tagsizlar = message.guild.members.cache.filter(s => !s.user.username.includes(tag) && s.user.discriminator.includes(etiket) && !s.user.username.includes(tag2) && s.user.username.includes(tag3) && s.user.username.includes(tag4) && s.user.username.includes(tag6) && s.user.username.includes(tag7) && s.roles.cache.has(rol))


    taglilar.array().forEach(async(member, index) => {  
        setTimeout(async() => {
            await member.roles.add(rol)
        }, index * 4000)
    })
    taglilar4.array().forEach(async(member, index) => {  
        setTimeout(async() => {
            await member.roles.add(rol)
        }, index * 4000)
    })
    
    taglilar2.array().forEach(async(member, index) => {
        setTimeout(async() => {
            await member.roles.add(rol)
        }, index * 4000)
    })
    
    taglilar3.array().forEach(async(member, index) => {
        setTimeout(async() => {
            await member.roles.add(rol)
        }, index * 4000)
    })

    taglilar6.array().forEach(async(member, index) => {
        setTimeout(async() => {
            await member.roles.add(rol)
        }, index * 4000)
    })

    taglilar7.array().forEach(async(member, index) => {
        setTimeout(async() => {
            await member.roles.add(rol)
        }, index * 4000)
    })

    etiketliler.array().forEach(async(member, index) => {
        setTimeout(async() => {
            await member.roles.add(rol)
        }, index * 4000)
    })
    tagsizlar.array().forEach(async(member, index) => {
        setTimeout(async() => {
            await member.roles.set(rol)
        }, index * 1000)
    })
  
    embed.setDescription(`
Tagımızı taşıyan ama rolü olmayan **${taglilar.size + taglilar2.size + taglilar3.size + etiketliler.size + taglilar4.size  + taglilar6.size + taglilar7.size}** üyeye <@&${rol}> rolü verildi.`)
    message.channel.send(embed)
}
module.exports.settings = {
    Commands: ["1949","tagt"],
    Usage: "tagt",
    Description: "Sunucunun bilgilerini atar.",
    Category: "Advanced",
    Activity: true
}