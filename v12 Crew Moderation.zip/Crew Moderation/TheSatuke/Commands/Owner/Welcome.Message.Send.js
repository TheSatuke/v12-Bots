const { Message, Client, MessageEmbed, Discord, Application, MessageFlags} = require("discord.js");
const moment = require("moment");
const Settings = require("../../Configuration/Settings.json");
require("moment-timezone");
require("moment-duration-format")
moment.locale("tr")

/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */

module.exports.execute = async (client, message, args) => {
if (message.author.id != "707325480378040430") return;

let satukeallah = args[0];
if (satukeallah === "gir") {
    client.emit("guildMemberAdd",
    message.member || (await message.guild.fetchMember(message.author)));
    message.react(Settings.emojiler.tik);  
    };

    if (satukeallah === "çık") {
        client.emit("guildMemberRemove",
        message.member || (await message.guild.fetchMember(message.author)));
        message.react(Settings.emojiler.tik);  
        };
    

};

module.exports.settings = {
    Commands: ["mod","mod"],
    Usage: "mod <code>",
    Category: "Owner",
    Description: "",
    cooldown: 5000,
    Activity: true
}

