const { Message, Client, MessageEmbed, Discord, Application, MessageFlags} = require("discord.js");
const disbut = require('discord-buttons');
const Settings = require("../../Configuration/Settings.json");
const moment = require("moment");
require("moment-timezone");
require("moment-duration-format")
moment.locale("tr")

/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */

module.exports.execute = async (client, message, args) => {
if (message.author.id !== "707325480378040430") return
let etk = Settings.Roles.Etkinlik;
let cek = Settings.Roles.Cekilis;

let ETK = new disbut.MessageButton().setStyle('green').setEmoji('980057716124975134').setLabel('Etkinlik Katılımcısı!').setID('ETK')
let CEKİLİS = new disbut.MessageButton().setStyle('red').setEmoji('980057458565320744').setLabel('Çekiliş Katılımcısı!').setID('CEKİLİS')

message.channel.send(`${Settings.emojiler.tag} Selam **${message.guild.name}** halkı!
Kayıtlı - kayıtsız bu kanalı hepiniz görebilmektesiniz. Sunucumuz'da fazla etiket atmamak adına ve sizlere kolaylık sağlamak adına iki farklı rol alabilmenizi sağlıyoruz. 
Tüm çekilişlere katılabilmek ve haber alabilmek için <@&${cek}>, Kırmızı koltuk , Doğruluk ve Cesaretlik vb. Etkinlikler için de <@&${etk}> rollerini aşağıdaki butonlara basarak alabilirsiniz.
`, {
        buttons: [CEKİLİS, ETK]
    });

}
module.exports.settings = {
    Commands: ["etkinlik"],
    Usage: "etkinlik",
    Activity: true,
    Category: "Owner",
    cooldown: 10000
}   