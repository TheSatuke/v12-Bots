const { MessageEmbed, Client, Message } = require("discord.js");
const Discord = require('discord.js');
const disbut = require("discord-buttons");
const client = global.client;
const Settings = require("../../Configuration/Settings.json");

const burclar = { "931658642955075604": Settings.Burc.Yengec, "931657544756248606": Settings.Burc.Aslan, "931658863923593297": Settings.Burc.Akrep, "931658464512598056": Settings.Burc.Oğlak, "931657587886264340": Settings.Burc.Balık, "931658178482012201": Settings.Burc.Başak, "931658397860892672": Settings.Burc.Kova, "931658529314603008": Settings.Burc.Terazi, "931658575951048714": Settings.Burc.Yay, "931658251181887508": Settings.Burc.Koç, "931658687028789289": Settings.Burc.İkizler, "931659095629529168": Settings.Burc.Boğa};
const renkler = {"🥥": Settings.Colors.White, "🍓": Settings.Colors.Red, "🍏": Settings.Colors.Green, "🍋": Settings.Colors.Yellow, "💙": Settings.Colors.Blue, "🍇": Settings.Colors.Purple};
const ilişki = {"💍": Settings.Lovers.Lovers, "💔": Settings.Lovers.Alone, "🖤": Settings.Lovers.NoSevgili}; 
const oyunlar = {"880606175274598461": Settings.Game.CSGO, "880606175761145906": Settings.Game.Lol,"880606175387873281": Settings.Game.Valorant, "880606175408824321": Settings.Game.GtaV, "880606175178153994": Settings.Game.Pubg, "880606175488540693": Settings.Game.Fortnite,};

module.exports.execute = async (client, message, args) => {
 
      const burcPush = [];
      const oyunPush = [];
      const renkPush = [];
      const digerPush = [];
      const emoji = (name) => client.emojis.cache.find(x => x.name === name);
    
      for (const burc in burclar) {
        let sonuc = burclar[burc];
        let table = new disbut.MessageMenuOption()
          .setLabel(message.guild.roles.cache.get(sonuc) ? message.guild.roles.cache.get(sonuc).name : sonuc)
          .setValue(sonuc)
          .setEmoji(emoji(burc) ? emoji(burc).id : burc)
     burcPush.push(table);
      };
      let kaldırburc = new disbut.MessageMenuOption()
      .setLabel("Rol İstemiyorum")
      .setEmoji("🗑️")
      .setValue("kaldır")
      let burc = new disbut.MessageMenu()
        burc.setID("burc")
        burc.setPlaceholder(`Burç Rolleri`)
        burc.setMaxValues(1)
        burc.setMinValues(1)
        burc.addOptions(burcPush,kaldırburc)
    
    
      for (const oyun in oyunlar) {
        const sonuc = oyunlar[oyun];
        let table = new disbut.MessageMenuOption()
          .setLabel(message.guild.roles.cache.get(sonuc) ? message.guild.roles.cache.get(sonuc).name : sonuc)
          .setEmoji(emoji(oyun) ? emoji(oyun).id : oyun)
          .setValue(sonuc)
         oyunPush.push(table);
      };
      let kaldıroyun = new disbut.MessageMenuOption()
      .setLabel("Rol İstemiyorum")
      .setEmoji("🗑️")
      .setValue("kaldır")
      let oyun = new disbut.MessageMenu();
      oyun.setID("oyun");
      oyun.setPlaceholder(`Oyun Rolleri`)
      oyun.setMaxValues(6);
      oyun.setMinValues(1);
      oyun.addOptions(oyunPush,kaldıroyun);
    
   for (const renk in renkler) {
        const sonuc = renkler[renk];
        let table = new disbut.MessageMenuOption()
          .setLabel(message.guild.roles.cache.get(sonuc) ? message.guild.roles.cache.get(sonuc).name : sonuc)
          .setEmoji(emoji(renk) ? emoji(renk).id : renk)
          .setValue(sonuc)
        renkPush.push(table);
      };
      let kaldırrenk = new disbut.MessageMenuOption()
      .setLabel("Rol İstemiyorum")
      .setEmoji("🗑️")
      .setValue("kaldır")
      let renk = new disbut.MessageMenu();
      renk.setID("renk");
      renk.setPlaceholder(`Renk Rolleri`)
      renk.setMaxValues(1);
      renk.setMinValues(1);
      renk.addOptions(renkPush,kaldırrenk);
    
  
    
      for (const diger in ilişki) {
        const sonuc = ilişki[diger];
        let table = new disbut.MessageMenuOption()
          .setLabel(message.guild.roles.cache.get(sonuc) ? message.guild.roles.cache.get(sonuc).name : sonuc)
          .setEmoji(emoji(diger) ? emoji(diger).id : diger)

          .setValue(sonuc)
        digerPush.push(table);
      };
      let kaldırdiger = new disbut.MessageMenuOption()
      .setLabel("Rol İstemiyorum")
      .setEmoji("🗑️")
      .setValue("kaldır")
      let diger = new disbut.MessageMenu();
      diger.setID("diger");
      diger.setPlaceholder(`İlişki Rolleri`)
      diger.setMaxValues(1);
      diger.setMinValues(1);
      diger.addOptions(digerPush,kaldırdiger);
  
  }


      
      module.exports.settings = {
    Commands: ["select"],
    Usage: "select <id>",
    Description: "",
    Category: "Owner",
    Activity: true
}
