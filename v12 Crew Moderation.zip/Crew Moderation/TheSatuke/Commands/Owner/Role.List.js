const {MessageEmbed, Discord } = require('discord.js');
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");
const afk = require("../../Models/Database/Afk");
  
module.exports.execute = async (client, message, args) => {
    if(!message.member.hasPermission("ADMINISTRATOR") && !Settings.Roles.Commanders.some(authRole => message.member.roles.cache.has(authRole)))
    return message.lineReply(`${Settings.emojiler.iptal} Bu komudu kullanmaya yetkin yetmiyor :c`).then(x => x.delete({timeout: 7500}));

    let A = message.guild.members.cache.filter(x => x.permissions.has("ADMINISTRATOR")).map(x => x.user).join(", ")
    let R = message.guild.members.cache.filter(x => x.permissions.has("MANAGE_ROLES")).map(x => x.user).join(", ")
    let S = message.guild.members.cache.filter(x => x.permissions.has("MANAGE_GUILD")).map(x => x.user).join(", ")

    let ask = new MessageEmbed().setColor(Config.EmbedColor)

message.lineReply(ask.setDescription(`  
\`\`\`diff
Sunucuda "Yönetici" permi açık olan kişiler:\`\`\`
${A}

\`\`\`diff
Sunucuda "Rol yönet" permi açık olan kişiler:\`\`\`
${R}

\`\`\`diff
Sunucuda "Sunucuyu yönet" permi açık olan kişiler:\`\`\`
${S}
`))
} 
    
module.exports.settings = {
    Commands: ["rollist"],
    Usage: "rollist",
    Description: "",
    Category: "Advanced",
    Activity: true
}
