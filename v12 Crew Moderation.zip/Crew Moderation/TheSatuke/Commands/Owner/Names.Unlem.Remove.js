const { MessageEmbed } = require('discord.js')
const Config = require("../../Configuration/Config.json");
const Settings = require("../../Configuration/Settings.json");
const ms = require("ms")
const moment = require("moment")
require("moment-duration-format")
/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */

module.exports.execute = async (client, message, args) => {
  if(!message.member.hasPermission("ADMINISTRATOR"))
  return message.lineReply(`${Settings.emojiler.iptal} Bu komudu kullanmaya yetkin yetmiyor :c`).then(x => x.delete({timeout: 7500}));
     
    let ünlemliler = message.guild.members.cache.filter(x => x.displayName.includes("!"))
    ünlemliler.forEach(async (member) => {
       await member.setNickname(member.displayName.replace("!"," ")).catch(err => {})
    })
    message.lineReply(`Başarıyla **${ünlemliler.size}** üyenin isminde ki __ünlem, özel karakter__ kaldırıldı.`).then(x => {
    })

  }

module.exports.settings = {
    Commands: ["unlemkaldır", "isim-ünlemtemizle", "unlemkaldir", "ümlemlerikaldır"],
    Usage: "ünlemkaldır",
    Activity: true,
    permLevel: 7,   
    Category: "Owner",
    cooldown: 10000
}