const {MessageEmbed, Discord } = require('discord.js');
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");
const afk = require("../../Models/Database/Afk");
  
module.exports.execute = async (client, message, args) => {
    if(!message.member.hasPermission("ADMINISTRATOR") && !Settings.Roles.Commanders.some(authRole => message.member.roles.cache.has(authRole)))
    return message.lineReply(`${Settings.emojiler.iptal} Bu komudu kullanmaya yetkin yetmiyor :c`).then(x => x.delete({timeout: 7500}));

    let A = message.guild.roles.cache.filter(s => s.permissions.has("ADMINISTRATOR"))
    let R = message.guild.roles.cache.filter(s => s.permissions.has("MANAGE_ROLES"))
    let C = message.guild.roles.cache.filter(s => s.permissions.has("MANAGE_CHANNELS"))
    let S = message.guild.roles.cache.filter(s => s.permissions.has("MANAGE_GUILD"))

    let guild = client.guilds.cache.get(Settings.Server.Id);
    let ask = new MessageEmbed().setColor(Config.EmbedColor)

    message.lineReply(ask.setDescription(`  
Sunucuda Yönetici olan roller (**${A.size}**)
${A.map(s => `${message.guild.roles.cache.get(s.id)}`)}

Sunucuda Rol yönet olan roller (**${R.size}**)
${R.map(s => `${message.guild.roles.cache.get(s.id)}`)}

Sunucuda Kanal yönet olan roller (**${C.size}**)
${C.map(s => `${message.guild.roles.cache.get(s.id)}`)}

Sunucuda Sunucuyu yönet olan roller (**${S.size}**)
${S.map(s => `${message.guild.roles.cache.get(s.id)}`)}
`))
} 
    
module.exports.settings = {
    Commands: ["rolkontrol"],
    Usage: "rolkontrol",
    Description: "",
    Category: "Advanced",
    Activity: true
}
