const client = global.Client;
const { Client, Discord, MessageEmbed } = require("discord.js");
const moment = require("moment");
const db = require("quick.db");
const disbut = require('discord-buttons');
require("discord-buttons")(client)

const Config = require("./Configuration/Config.json");
const Settings = require("./Configuration/Settings.json");
moment.locale("tr");
const Events = require("./Managers/EventManager");

Events.addEvent("Afk")
Events.addEvent("autoReply");
Events.addEvent("CommandHandler");
Events.addEvent("Timer.js");
Events.addEvent("Penal/OnMemberUpdate");
Events.addEvent("Penal/OnReady");
Events.addEvent("Penal/OnVoiceStateUpdate");
Events.addEvent("guildMemberUpdate");
Events.addEvent("messageDelete");
Events.addEvent("clickButton");
Events.addEvent("messageUpdate");
Events.addEvent("voiceUpdate");
Events.addEvent("Tag/UserUpdate");
const katılımcı = {
  "941075067230625803": "Etkinlik_Rol_İd",
  "941074179401338900": "Çekiliş_Rol_İd"
}; 

const burclar = {

  "931658642955075604": "987084206175838228",
  "931657544756248606": "987084209900384396",
  "931658863923593297": "987084212907688076",
  "931658464512598056": "987084215860478084",
  "931657587886264340": "987084219228491827",
  "931658178482012201": "987084211070582804",
  "931658397860892672": "987084216967786547",
  "931658529314603008": "987084207375388732",
  "931658575951048714": "987084214409244754",
  "931658251181887508": "987084202543566918",
  "931658687028789289": "987084205055967233",
  "931659095629529168": "987084203411775568"

  };

const renkler = {
  "🥥": "987084143215132692",
  "🍓": "987084144662175765",
  "🍏": "988090541113770065",
  "🍋": "987084146788691988",
  "🍇": "987084147686248470",
  "🍇": "987084148650959008"
};

const ilişki = {
  "💍": "987084194779914250",
  "💔": "987084197502001152",
  "🖤":"987084195635527740",
}; 

const oyunlar = {
  "880606175274598461":"987084243102478398",
  "880606175761145906":"987084241789673533",
  "880606175387873281":"987084248420843611",
  "880606175408824321":"987084240682369236",
  "880606175178153994":"987084245933633536",
  "880606175488540693":"987084244964745286"
};

//const onLoad = require("./Logger");
require("./Utils/Helper");
require("./Utils/Patch");

client.on("ready", async () => {
  var status = [
    "Schâwn ❤️ satuke.",
    "Schâwn ❤️ satuke.",
    "Schâwn ❤️ satuke.",
    "Schâwn ❤️ satuke.",
    "Schâwn ❤️ satuke.",
    "Schâwn ❤️ satuke."]    
    
    setInterval(function() {
            var random = Math.floor(Math.random()*(status.length-0+1)+0);
            client.user.setActivity(status[random], { type: 'LISTENING' });
            }, 1 * 1000); 
});
client.on("message", async message => {
  if (message.content === "!gir") {if(!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send("Başarısız.");
    client.emit(
      "guildMemberAdd",
      message.member || (await message.guild.fetchMember(message.author))
    );
  }
});
//  console.log(`Toplam ${client.guilds.cache.size} adet sunucuda var bot!\n${client.guilds.cache.map(x => `İsim:${x.name} | Üye Sayısı: ${x.memberCount} | Oluşturulma Tarihi ${moment(x.createdAt).fromNow()} | Ses Sayısı: ${x.members.cache.filter(x=> x.voice.channel).size} | Botun Sesi:}`).join("\n")}`)

client.on("clickMenu", async (menu) => {

  if (menu.id == "katılım") {
    await menu.reply.think(true);
    await menu.reply.edit("Rollerin güncellendi!");
    let add = [];
    let remove = [];
    let allRemove = [];
    let roller = katılımcı;
    for (const rol in roller) {
      let sonuc = roller[rol];
      allRemove.push(sonuc);
      if (menu.values.includes(sonuc)) {
      await menu.reply.edit(`Başarılı bir şekilde <@&${sonuc}> rolü üzerinize eklendi!`);
        add.push(sonuc);
      } else {
        remove.push(sonuc);
      };
    };
    if (!menu.values.some(value => value === "allDelete")) {
      if (remove.length > 0) {
        await menu.clicker.member.roles.remove(remove);

      };
      await menu.clicker.member.roles.add(add);
    

    } else {
      await menu.clicker.member.roles.remove(allRemove);
     

    };
    };


  if (menu.id == "burc") {
      await menu.reply.think(true);
      await menu.reply.edit("Rollerin güncellendi!");
      let add = [];
      let remove = [];
      let allRemove = [];
      let roller = burclar;
      for (const rol in roller) {
        let sonuc = roller[rol];
        allRemove.push(sonuc);
        if (menu.values.includes(sonuc)) {
        await menu.reply.edit(`Başarılı bir şekilde <@&${sonuc}> rolü üzerinize eklendi!`);
          add.push(sonuc);
        } else {
          remove.push(sonuc);
        };
      };
      if (!menu.values.some(value => value === "allDelete")) {
        if (remove.length > 0) {
          await menu.clicker.member.roles.remove(remove);
  
        };
        await menu.clicker.member.roles.add(add);
      

      } else {
        await menu.clicker.member.roles.remove(allRemove);
       

      };
      };

  if (menu.id == "oyun") {
    await menu.reply.think(true);
    await menu.reply.edit("Rollerin güncellendi!");
    let add = [];
    let remove = [];
    let allRemove = [];
    let roller = oyunlar;
    for (const rol in roller) {
      let sonuc = roller[rol];
      allRemove.push(sonuc);
      if (menu.values.includes(sonuc)) {
          
        await menu.reply.edit(`Başarılı bir şekilde <@&${sonuc}> rolü üzerinize eklendi!`);
        add.push(sonuc);
      } else {
        remove.push(sonuc);
      };
    };
    if (!menu.values.some(value => value === "allDelete")) {
      if (remove.length > 0) {
        await menu.clicker.member.roles.remove(remove);
      };
      await menu.clicker.member.roles.add(add);
      await menu.clicker.member.roles.add(sonuc);
    } else {
      await menu.clicker.member.roles.remove(allRemove);

    };
  };

  if (menu.id == "renk") {
    await menu.reply.think(true);
    if (!menu.clicker.member.roles.cache.get("987084153654771793") && !menu.clicker.member.roles.cache.get("981322425050488845")) return await menu.reply.edit("aileden olman gerek!");;
    await menu.reply.edit("Rollerin güncellendi!");

    let add = [];
    let remove = [];
    let allRemove = [];
    let roller = renkler;
    for (const rol in roller) {

      let sonuc = roller[rol];  

      allRemove.push(sonuc);
      if (menu.values.includes(sonuc)) {    
        await menu.reply.edit(`Başarılı bir şekilde <@&${sonuc}> rolü üzerinize eklendi!`);

        add.push(sonuc);
      } else {
        remove.push(sonuc);

      };
    };
    if (!menu.values.some(value => value === "allDelete")) {
      if (remove.length > 0) {
        await menu.clicker.member.roles.remove(remove);
      };
      await menu.clicker.member.roles.add(add);
    } else {
      await menu.clicker.member.roles.remove(allRemove);

    };
  };
  if (menu.id == "diger") {
    await menu.reply.think(true);
    await menu.reply.edit("Rollerin güncellendi!");
    let add = [];
    let remove = [];
    let allRemove = [];
    let roller = ilişki;
    for (const rol in roller) {
      let sonuc = ilişki[rol];
      allRemove.push(sonuc);
      if (menu.values.includes(sonuc)) {
          
        await menu.reply.edit(`Başarılı bir şekilde <@&${sonuc}> rolü üzerinize eklendi!`);
        add.push(sonuc);
      } else {
        remove.push(sonuc);
      };
    };
    if (!menu.values.some(value => value === "allDelete")) {
      if (remove.length > 0) {
        await menu.clicker.member.roles.remove(remove);
       

      };
      await menu.clicker.member.roles.add(add);
    } else {
      await menu.clicker.member.roles.remove(allRemove);
    };
  };

 
});

client.on("guildMemberAdd", member => {
  require("moment-duration-format")
  const kanal = member.guild.channels.cache.find(r => r.id === "987084303668232252");
  if (member.user.bot) return member.roles.add("985127865563639879");
  if (Date.now() - member.user.createdTimestamp < 1000 * 60 * 60 * 24 * 7) {
    member.setNickname("• Şüpheli Hesap").catch();
    member.setRoles(Settings.Roles.Süpheli)
  kanal.send(`${Settings.emojiler.iptal} ${member} (\`${member.id}\`) Adlı kullanıcının hesabı yeni açıldığı için jaile atıldı.`)
  member.send(`Hesabın 7 günden az bi sürede açıldığı için jaile atıldın. Eğer bir yanlışlık olduğunu düşünüyorsan yanda bulunan yetkililere yazabilirsin.`)}
  else {
  let user = client.users.cache.get(member.id);
  const kurulus = new Date().getTime() - user.createdAt.getTime();
  var kontrol;
  if (kurulus < 604800) kontrol = Settings.emojiler.iptal;
  if (kurulus > 604800) kontrol = Settings.emojiler.tik;
member.roles.add(Settings.Roles.Unregistered)

if (member.user.username.includes("✦")) { member.setNickname(`✦ İsim | Yaş`).catch(); }
else { member.setNickname(`• İsim | Yaş`).catch();}
moment.locale("tr");
kanal.send(`${Settings.emojiler.tag} ${member} Maesta'ya hoş geldin, seninle beraber sunucumuz **${member.guild.memberCount}** üye sayısına ulaştı.

Hesabın **<t:${Math.floor(member.user.createdTimestamp / 1000)}:D>** tarihinde oluşturulmuş ${kontrol}

Unutma sunucu kurallarımız <#987084307891880078> kanalında belirtilmiştir, Unutma sunucu içerisinde ki ceza işlemlerin kuralları okuduğunu varsayarak gerçekleştirilecek. :tada:`)


}}) 



client.on('clickButton', async (button, message, guild, guildID) => {
  if (button.id === 'CEKİLİS') {
      if (button.clicker.member.roles.cache.get(etk)) {
          await button.clicker.member.roles.remove(etk);
          await button.reply.send('Rol Başarıyla Üzerinden Alındı!', true);
        } else {
          await button.clicker.member.roles.add(etk);
          await button.reply.send('Rol Başarıyla Üzerine Eklendi!', true);

        }
  }
  if (button.id === 'ETK') {
      if (button.clicker.member.roles.cache.get(cek)) {
          await button.clicker.member.roles.remove(cek);
          await button.reply.send('Rol Başarıyla Üzerinden alındı!', true);
      } else {
          await button.clicker.member.roles.add(cek);
          await button.reply.send('Rol Başarıyla Üzerine Eklendi!', true);
      }

  }
}
)

let etk = Settings.Roles.Etkinlik
let cek = Settings.Roles.Cekilis

  client.on("message", async (message) => {
    const args = message.content.split(" ");
    const command = args.shift();
    if (command === "!etkinlik" && "707325480378040430" == message.author.id) {
    let ETK = new disbut.MessageButton().setStyle('green').setEmoji('980057716124975134').setLabel('Etkinlik Katılımcısı!').setID('ETK')
    let CEKİLİS = new disbut.MessageButton().setStyle('red').setEmoji('980057458565320744').setLabel('Çekiliş Katılımcısı!').setID('CEKİLİS')
message.channel.send(`${Settings.emojiler.tag} Selam **Maesta** halkı!

> Kayıtlı - kayıtsız bu kanalı hepiniz görebilmektesiniz. Sunucumuz'da fazla etiket atmamak adına ve sizlere kolaylık sağlamak adına iki farklı rol alabilmenizi sağlıyoruz. 
> Tüm çekilişlere katılabilmek ve haber alabilmek için <@&${cek}>, Kırmızı koltuk , Doğruluk ve Cesaretlik vb. Etkinlikler için de <@&${etk}> rollerini aşağıdaki butonlara basarak alabilirsiniz.
`, {
        buttons: [CEKİLİS, ETK]
    });
}
});

require("./Functions/Client.Login")
