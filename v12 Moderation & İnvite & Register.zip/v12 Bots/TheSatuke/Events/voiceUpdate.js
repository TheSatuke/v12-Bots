
const client = global.Client;
const { Client, Discord, MessageEmbed } = require("discord.js");
const Settings = require("../Configuration/Settings.json");
module.exports = (oldMember, newMember) => {
    var log = client.channels.cache.get("987859553175621633");
  
  
    if (oldMember.channelID && !oldMember.serverMute && newMember.serverMute) return log.send(`**${newMember.guild.members.cache.get(newMember.id).displayName}** kullanıcısı <#${newMember.guild.channels.cache.get(newMember.channelID).id}> adlı sesli kanalda yetkili tarafından **__susturdu__!**`).catch();
    if (!oldMember.channelID && newMember.channelID) return log.send(`**${newMember.guild.members.cache.get(newMember.id).displayName}** üyesi <#${newMember.guild.channels.cache.get(newMember.channelID).id}> adlı sesli kanala **__katıldı__!**`).catch();
    if (oldMember.channelID && !newMember.channelID) return log.send(`**${newMember.guild.members.cache.get(newMember.id).displayName}** üyesi <#${newMember.guild.channels.cache.get(oldMember.channelID).id}> adlı sesli kanaldan **__ayrıldı__!**`).catch();
    if (oldMember.channelID && newMember.channelID && oldMember.channelID != newMember.channelID) return log.send(`**${newMember.guild.members.cache.get(newMember.id).displayName}** üyesi ses kanalını **değiştirdi!** (<#${newMember.guild.channels.cache.get(oldMember.channelID).id}> => <#${newMember.guild.channels.cache.get(newMember.channelID).id}>)`).catch();
    if (oldMember.channelID && oldMember.selfMute && !newMember.selfMute) return log.send(`**${newMember.guild.members.cache.get(newMember.id).displayName}** kullanıcısı <#${newMember.guild.channels.cache.get(newMember.channelID).id}> adlı sesli kanalda kendi susturmasını **__kaldırdı__!**`).catch();
    if (oldMember.channelID && !oldMember.selfMute && newMember.selfMute) return log.send(`**${newMember.guild.members.cache.get(newMember.id).displayName}** kullanıcısı <#${newMember.guild.channels.cache.get(newMember.channelID).id}> adlı sesli kanalda kendini **__susturdu__!**`).catch();
    if (oldMember.channelID && oldMember.selfDeaf && !newMember.selfDeaf) return log.send(`**${newMember.guild.members.cache.get(newMember.id).displayName}** kullanıcısı <#${newMember.guild.channels.cache.get(newMember.channelID).id}> adlı sesli kanalda kendi sağırlaştırmasını **__kaldırdı!__**`).catch();
    if (oldMember.channelID && !oldMember.selfDeaf && newMember.selfDeaf) return log.send(`**${newMember.guild.members.cache.get(newMember.id).displayName}** kullanıcısı <#${newMember.guild.channels.cache.get(newMember.channelID).id}> adlı sesli kanalda kendini **__sağırlaştırdı!__**`).catch();
  
    };

module.exports.config = {
    Event: "voiceStateUpdate"
}