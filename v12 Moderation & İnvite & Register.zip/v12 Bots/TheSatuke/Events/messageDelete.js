const Settings = require("../Configuration/Settings.json");
const { Client, Discord, MessageEmbed } = require("discord.js");

module.exports = (message) => {
   let log2 = message.guild.channels.cache.get("988092374301429820") 
   if(log2) {
   if (message.author.bot || message.channel.type == "dm") return;
   const satuke = new MessageEmbed().setTimestamp()
   if (message.attachments.first()) {
   log2.send(satuke.setAuthor(`${message.author.tag} | Fotoğraf Silindi`, message.author.avatarURL()).setDescription(`<#${message.channel.id}> kanalında <@!${message.author.id}> tarafından bir fotoğraf silindi. 
   
 ${Settings.emojiler.yıldız} **Fotoğraf İçeriği:** `).setImage(message.attachments.first().proxyURL).setColor(Config.EmbedColor).setFooter(`Maesta created by Satuke`));} 
       else {
   log2.send(satuke.setAuthor(`${message.author.tag} | Mesaj Silindi`, message.author.avatarURL()).setDescription(`<#${message.channel.id}> kanalında <@!${message.author.id}> tarafından bir mesaj silindi.
   
 ${Settings.emojiler.yıldız} **Mesaj İçeriği:** ${message.content}`).setColor(Config.EmbedColor).setFooter(`Maesta created by Satuke`));
       }}
   }
module.exports.config = {
    Event: "messageDelete"
}