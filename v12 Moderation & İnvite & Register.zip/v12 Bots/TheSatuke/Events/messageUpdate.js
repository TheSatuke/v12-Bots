const Settings = require("../Configuration/Settings.json");
const { Client, Discord, MessageEmbed } = require("discord.js");
module.exports = (oldMessage, newMessage) => {
    let log1 = oldMessage.guild.channels.cache.get("988092374301429820") 
    if(log1) {
    const sat = new MessageEmbed().setTimestamp()
        if (oldMessage.author.bot) return;
        if (!oldMessage.guild) return;
        if (oldMessage.content == newMessage.content) return;
        log1.send(sat.setAuthor(`${oldMessage.author.tag} | Mesaj Düzenlendi`, oldMessage.author.avatarURL()).setDescription(`<#${oldMessage.channel.id}> kanalında <@!${oldMessage.author.id}> tarafından bir mesaj düzenlendi.
    
  ${Settings.emojiler.yıldız} **Eski Mesaj:** ${oldMessage.content}  
  ${Settings.emojiler.yıldız} **Yeni Mesaj:** ${newMessage.content}
    `).setColor(Config.EmbedColor).setFooter(`Maesta created by Satuke`)); 
      }
    };

module.exports.config = {
    Event: "messageUpdate"
}