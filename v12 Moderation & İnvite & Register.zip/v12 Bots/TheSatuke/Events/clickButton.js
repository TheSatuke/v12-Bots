const Settings = require("../Configuration/Settings.json");

const moment = require("moment");
moment.locale("tr");

module.exports = async (button) => {
  

const member = await client.guilds.cache.get(Settings.Server.Id).members.fetch(button.clicker.member.id)
if (!member) return;

}
module.exports.config = {
    Event: "clickButton"
};
