const discord = require("discord.js")
const client = global.Client;
const { Client, MessageEmbed } = require("discord.js");
const Config = require("../Configuration/Config.json");
client.on('warn', m => console.log(`[WARN]:${m}`));
client.on('error', m => console.log(`[ERROR]: ${m}`));
client.on("disconnect", () => console.log("Bot bağlantısı kesildi"))
client.on("reconnecting", () => console.log("Bot tekrar bağlanıyor..."))
process.on('uncaughtException', error => console.log(`[ERROR]: ${error}`));
process.on('unhandledRejection', err => console.log(`[ERROR]: ${err}`));

client.login(Config.Token).then(x => 
console.log(`──────────────────────────────────────────────
Moderation Başarıyla Giriş Yaptı!`)).catch(err => console.error(`Bota Giriş Yapılamadı.!\nHata : ${err}`));