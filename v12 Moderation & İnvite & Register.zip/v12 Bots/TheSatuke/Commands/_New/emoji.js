const { Message, Client, MessageEmbed, Discord, Application, MessageFlags} = require("discord.js");
const Settings = require("../../Configuration/Settings.json");
const moment = require("moment");
require("moment-duration-format")
moment.locale("tr")

/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */
module.exports.execute = async (client, message, args) => {

    if(!message.member.hasPermission("MANAGE_EMOJIS")) return message.channel.send(new Discord.MessageEmbed().setTitle('Hata!').setColor('#ff0000').setDescription(`${message.author} bu komutu kullanabilmek için \`Emojileri Yönet\` Yetkisine sahip olmalısın.`));
    let link = args[0]
    let isim = args[1];
    let guild = message.guild;
    if (!isim) return message.channel.send('Emojiye isim seçmelisin');

    guild.emojis.create(`${link}`, `${isim}`)
        .then(emoji => 
         message.channel.send(`\`${isim}\` adlı emojiyi sunucuya ekledim.`))
        .catch(console.error);

  
}
module.exports.settings = {
    Commands: ["emoji","emoji"],
    Usage: "emoji <rol/id",
    Description: "",
    Category: "General",
    Activity: true
}
