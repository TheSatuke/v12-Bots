const {Client, MessageEmbed} = require("discord.js");
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");


/**
 * @param {Client} client 
 * @param {Message} message 
 * @param {Array<String>} args 
 */
module.exports.execute = async (client, message, args) => {

if(!message.member.roles.cache.get(Settings.Roles.Commander) && !message.member.hasPermission('ADMINISTRATOR'))
return message.lineReply(new MessageEmbed().setDescription(`${Settings.emojiler.iptal} yetkin yok oc`).setFooter(Config.Footer).setColor('RANDOM'))

let satuke = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
if(!satuke) return message.lineReply(new MessageEmbed().setDescription(`${Settings.emojiler.iptal} kullanıcı belirt askim`).setFooter(Config.Footer).setColor("RANDOM")).then(msg => msg.delete({timeout: 9000}))
const Embed = new MessageEmbed()
.setColor(Config.EmbedColor)
.setAuthor(message.member.displayName, message.author.avatarURL({dynamic: true}))
.setDescription(`${satuke}, kullanıcısına <@&${Settings.Yetenek.Vip}> rolü verildi!`)
message.lineReply(Embed)
satuke.roles.add(Settings.Yetenek.Vip)}

module.exports.settings = {
    Commands: ["vip"],
    Usage: "vip",
    Description: "Bahsettiğin kullanıcıya belirlenen yetenek rolünü verirsin!",
    Category: "Ability",
    Activity: true
}
