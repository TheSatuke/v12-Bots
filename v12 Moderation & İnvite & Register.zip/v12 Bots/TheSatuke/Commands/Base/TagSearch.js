const { MessageEmbed } = require('discord.js');
const Settings = require("../../Configuration/Settings.json");
const Config = require("../../Configuration/Config.json");


module.exports.execute = async (client, message, args) => {
    if(!message.member.hasPermission("ADMINISTRATOR") && !Settings.Roles.Yönetimr.some(authRole => message.member.roles.cache.has(authRole))) 
    return message.lineReply(`${Settings.emojiler.iptal} ${Text.YetkinYetmiyor}`);

    const tag_1 = "✦";

    let rol = Settings.Tag.Role;
    let Tag_1 = message.guild.members.cache.filter(s => s.user.username.includes("✦") && !s.roles.cache.has(rol))
    let TagsizKöpek = message.guild.members.cache.filter(s => !s.user.username.includes("✦")  && s.roles.cache.has(rol))

    Tag_1.array().forEach(async(member, index) => {  
        setTimeout(async() => {
            await member.roles.add(rol)
        }, index * 1000)
    })
    TagsizKöpek.array().forEach(async(member, index) => {
        setTimeout(async() => {
            await member.roles.set(rol)
        }, index * 1000)
    })
    
    
  
    message.lineReply(`Sunucuda tag taraması yapılıyor..`).then(x => x.edit(`${Settings.emojiler.tik} Rolü Verilecek Kişi Sayısı: **${Tag_1.size} **`))
  }
module.exports.settings = {
    Commands: ["tagt","TagTara","tagtara","tagsearch"],
    Usage: "tagtara",
    Description: "",
    Category: "Base",
    Activity: true
}
