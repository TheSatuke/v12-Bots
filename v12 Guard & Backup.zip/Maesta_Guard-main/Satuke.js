const { Client } = require("discord.js");
const client = global.Client = new Client({ fetchAllMembers: true });
const Settings = require("./Settings.json");
require("discord-reply")
const mongoose = require("mongoose");

mongoose.connect(Settings.Mongoose.DatabaseUrl.replace("<dbname>", Settings.Mongoose.DatabaseName), {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useFindAndModify: false
});

mongoose.connection.on("connected", () => { console.log('\x1b[32m%s\x1b[0m', ` [Mongoose] MongoDB'ye başarıyla bağlandım.`);})

require("./TheSatuke/Async.js");
require("./TheSatuke/Base/Spammer");
require("./TheSatuke/Cloud")
require("./TheSatuke/Data.js");
require("./TheSatuke/Guard.js");
