const Discord = require("discord.js");
const satuke = new Discord.Client(); 
const request = require('request');
const Settings = require("../../Settings.json");


satuke.on("ready", async () => {
    satuke.user.setStatus('online');
    satuke.user.setActivity(Settings.Server.Status, { type: 'LISTENING' })
    
    let botVoiceChannel = satuke.channels.cache.get(Settings.Server.VoiceChannel);
    if (botVoiceChannel) botVoiceChannel.join().catch(err => console.error("[BACKUP] Sese Bağlanamadı!"));
    const guild = satuke.guilds.cache.get(Settings.Server.GuildID)
    let logKanali = satuke.channels.cache.find(a => a.name == "url-audit-2")
    await logKanali.send(`Url Kontrol Ediliyor Durum: (\`Url Yerinde\`) 
    \`\`\`Bot yeniden başlatıldığı için kontrol ediliyor. \`\`\`\ `|| "Url Kontrol Ediliyor Durum: (\`Url Yerinde Değil\`)")


    setInterval(async () => {
    if(guild.vanityURLCode == Settings.Server.VanityURL) {
//    let logKanali = satuke.channels.cache.find(a => a.name == "url-denetim")
//    console.log(`Url Kontrol Ediliyor Durum: (\`Url Yerinde\`) `|| "Url Kontrol Ediliyor Durum: (\`Url Yerinde Değil\`)")  
}

    else {
    satukeeeeeee(Settings.Server.VanityURL, Settings.Server.GuildID, Settings.Token.Guard_4) }}, 1*1000)})

    async function satukeeeeeee(vanity, token) {
        const spammer = {
            url: `https://discord.com/api/v8/guilds/${Settings.Server.GuildID}/vanity-url`,
            body: {
            code: `${vanity}`},
            json: true,
            method: 'PATCH',
            headers: {
            "Authorization": `Bot ${Settings.Token.Guard_4}` }
            };

    request(spammer, (err, res, body) => {
        if (err) {
            return console.log(err)}})}


satuke.on("disconnect", () => console.log("Bot bağlantısı kesildi"))
satuke.on("reconnecting", () => console.log("Bot tekrar bağlanıyor..."))
            
satuke.login(Settings.Token.Guard_4).then(x => console.log(`\x1b[36m%s\x1b[0m`, ` [SPAMMER] - Olarak Başarıyla Giriş Yapıldı!`)).catch(err => console.error(`[ERROR] Hata : ${err}`))
            