const { Client } = require('discord.js');
const Async = new Client();
const Settings = require("../Settings.json");
const request = require('request');

Async.on("ready", async () => {
  Async.user.setStatus('online');
  Async.user.setActivity(Settings.Server.Status, { type: 'LISTENING' })
  let botVoiceChannel = Async.channels.cache.get(Settings.Server.VoiceChannel);
  if (botVoiceChannel) botVoiceChannel.join().catch(err => console.error("[ASYNC] Sese Bağlanamadı!"));
});

let bots = require("./Models/Güvenliler.json")
let guvenlibot = bots.whitelistBots;
let Güvenliler = require("./Models/Güvenliler.json");

function guvenli(kisiID) {
  let members = Async.guilds.cache.get(Settings.Server.GuildID).members.cache.get(kisiID);
  let guvenliler = Güvenliler.whitelistBots || [];
  if (!members || members.id === Async.user.id || members.id === Settings.Server.OwnerID || members.id === members.guild.owner.id || guvenliler.some(g => members.id === g.slice(1) || members.roles.cache.has(g.slice(1)))) return true
  else return false;
};
    
Async.on('guildUpdate', async (oldGuild, newGuild) => {
if (oldGuild.vanityURLCode === newGuild.vanityURLCode) return;
newGuild.members.ban(entry.executor.id, { reason: `URL Değiştirdiği için banlandı.`});
let entry = await newGuild.fetchAuditLogs({ type: 'GUILD_UPDATE' }).then(audit => audit.entries.first());
if (!entry.executor || guvenli(entry.executor.id) || entry.executor.id === Async.user.id) return;
let channel = Async.channels.cache.find(x => x.name == Settings.Log.Async_Log)
if (channel) channel.send(`${Settings.Emote.Diamond} ${entry.executor} (\`${entry.executor.id}\`) adlı kullanıcı **${Settings.Server.VanityURL}** isimli özel urlyi değiştirmeye çalıştı, @everyone

Ceza: ${entry.executor.bannable ? "Yasaklandı" : "Yasaklanamadı"}**`)

const bisiylerdeniyom = {
    url: `https://discord.com/api/v6/guilds/${newGuild.id}/vanity-url`,
    body: {
    code: Settings.Server.VanityURL },
    json: true,
    method: 'PATCH',
    headers: { "Authorization": `Bot ${Settings.Token.Async}` }
};

request(bisiylerdeniyom, (err, res, body) => {
    if (err) {
        return console.log(err);
    }
});
});

Async.on('warn', m => console.log(`[WARN]:${m}`));
Async.on('error', m => console.log(`[ERROR]: ${m}`));
Async.on("disconnect", () => console.log("Bot bağlantısı kesildi"))
Async.on("reconnecting", () => console.log("Bot tekrar bağlanıyor..."))
process.on('uncaughtException', error => console.log(`[ERROR]: ${error}`));
process.on('unhandledRejection', err => console.log(`[ERROR]: ${err}`));
Async.login(Settings.Token.Async).then(x => console.log('\x1b[36m%s\x1b[0m',` [ARSENIC] - Olarak Başarıyla Giriş Yapıldı!`)).catch(err => console.error(`[ERROR] Hata : ${err}`))