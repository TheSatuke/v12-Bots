const { Discord, Client, MessageEmbed, WebhookClient  } = require('discord.js');
const client = global.client = new Client({fetchAllMembers: true});
const Settings = require("../Settings.json");
const userRoles = require("../TheSatuke/Models/Web");

const fs = require('fs');
const mongoose = require('mongoose');
const moment = require("moment")
moment.locale("tr");

mongoose.connect(Settings.Mongoose.DatabaseUrl, {useNewUrlParser: true, useUnifiedTopology: true});
const Database = require("./Models/RoleBackup");

client.on("ready", async () => {
  client.user.setStatus('online');
  client.user.setActivity(Settings.Server.Status, { type: 'LISTENING' })
  let botVoiceChannel = client.channels.cache.get(Settings.Server.VoiceChannel);
  if (botVoiceChannel) botVoiceChannel.join().catch(err => console.error("[BACKUP] Sese Bağlanamadı!"));
});
// ************************************************************************************************************************************* //

  setRoleBackup();
  setInterval(() => {
    setRoleBackup();
  }, 150 * 900);;

// ************************************************************************************************************************************* //  

client.on("message", async message => {
  if (message.author.bot || !message.guild || !message.content.toLowerCase().startsWith(Settings.Prefix.BackupPrefix)) return;
  if (message.author.id !== Settings.Server.OwnerID && message.author.id !== message.guild.owner.id) return;
  let args = message.content.split(' ').slice(1);
  let command = message.content.split(' ')[0].slice(Settings.Prefix.BackupPrefix.length);
  
  if (command === "eval" && message.author.id === Settings.Server.OwnerID) {
    if (!args[0]) return;
      let code = args.join(' ');
      function clean(text) {
      if (typeof text !== 'string') text = require('util').inspect(text, { depth: 0 })
      text = text.replace(/`/g, '`' + String.fromCharCode(8203)).replace(/@/g, '@' + String.fromCharCode(8203))
      return text;
    };
    try { 
      var evaled = clean(await eval(code));
      if(evaled.match(new RegExp(`${client.token}`, 'g'))) evaled.replace(client.token, "Yasaklı komut");
      message.channel.send(`${evaled.replace(client.token, "Yasaklı komut")}`, {code: "js", split: true});
    } catch(err) { message.channel.send(err, {code: "js", split: true}) };
    
 };
  
  
// ************************************************************************************************************************************* //

  if(command === "kur" || command === "kurulum" || command === "backup" || command === "setup") {
    if (!args[0] || isNaN(args[0])) return message.lineReply("Geçerli bir \`Rol ID\` belirtmelisin.");

    Database.findOne({guildID: Settings.Server.GuildID, roleID: args[0]}, async (err, roleData) => {
      if (!roleData) return message.channel.send("Belirttiğin \`Rol ID'sine\` ait veri bulamadım.");
      let yeniRol = await message.guild.roles.create({
        data: {
          name: roleData.name,
          color: roleData.color,
          hoist: roleData.hoist,
          permissions: roleData.permissions,
          position: roleData.position,
          mentionable: roleData.mentionable
        },
        reason: "Rol silindiği için tekrar oluşturuldu."
      });


      setTimeout(() => {
        let kanalPermVeri = roleData.channelOverwrites;
        if (kanalPermVeri) kanalPermVeri.forEach((perm, index) => {
          let kanal = message.guild.channels.cache.get(perm.id);
          if (!kanal) return;
          setTimeout(() => {
            let yeniKanalPermVeri = {};
            perm.allow.forEach(p => {
              yeniKanalPermVeri[p] = true;
            });
            perm.deny.forEach(p => {
              yeniKanalPermVeri[p] = false;
            });
            kanal.createOverwrite(yeniRol, yeniKanalPermVeri).catch(console.error);
          }, index*1500);
        });
      }, 1500);




      let roleMembers = roleData.members;
      roleMembers.forEach((member, index) => {
        let uye = message.guild.members.cache.get(member);
        if (!uye || uye.roles.cache.has(yeniRol.id)) return;
        setTimeout(() => {
          uye.roles.add(yeniRol.id).catch(console.error);
        }, index*850);
      });


   

      let logKanali = client.channels.cache.find(a => a.name == Settings.Log.DatabaseLog)
      if (logKanali) { logKanali.send(`🛡️ ${message.author} tarafından (\`${roleData.name}\`), (\`${roleData.roleID}\`) Rolün yedeği kurulmaya başladı

${Settings.Emote.Diamond} **Kurulma Tarihi:** ${moment(Date.now()).format("LLL")}`).catch(); }
      else { message.guild.owner.send(`🛡️ ${message.author} tarafından (\`${roleData.name}\`), (\`${roleData.roleID}\`) Rolün yedeği kurulmaya başladı, üyelere dağıtılmaya, kanalların izinlerine eklenmeye başlanıyor (Log Olmadığı için sana attım!)`).catch(err => {}); };
    });
  };
});



function setRoleBackup() {
  let guild = client.guilds.cache.get(Settings.Server.GuildID);
  let DatabaseLog = client.channels.cache.find(a => a.name == Settings.Log.DatabaseLog)
  if (guild) {
    guild.roles.cache.filter(r => r.name !== "@everyone" && !r.managed).forEach(role => {
      let roleChannelOverwrites = [];
      guild.channels.cache.filter(c => c.permissionOverwrites.has(role.id)).forEach(c => {
        let channelPerm = c.permissionOverwrites.get(role.id);
        let pushlanacak = { id: c.id, allow: channelPerm.allow.toArray(), deny: channelPerm.deny.toArray() };
        roleChannelOverwrites.push(pushlanacak);
      });

      Database.findOne({guildID: Settings.Server.GuildID, roleID: role.id}, async (err, savedRole) => {
        if (!savedRole) {
          let newRoleSchema = new Database({
            _id: new mongoose.Types.ObjectId(),
            guildID: Settings.Server.GuildID,
            roleID: role.id,
            name: role.name,
            color: role.hexColor,
            hoist: role.hoist,
            position: role.position,
            permissions: role.permissions,
            mentionable: role.mentionable,
            time: Date.now(),
            members: role.members.map(m => m.id),
            channelOverwrites: roleChannelOverwrites
          });
          newRoleSchema.save();
        } else {
          savedRole.name = role.name;
          savedRole.color = role.hexColor;
          savedRole.hoist = role.hoist;
          savedRole.position = role.position;
          savedRole.permissions = role.permissions;
          savedRole.mentionable = role.mentionable;
          savedRole.time = Date.now();
          savedRole.members = role.members.map(m => m.id);
          savedRole.channelOverwrites = roleChannelOverwrites;
          savedRole.save();
        };
      });
    });

    Database.find({guildID: Settings.Server.GuildID}).sort().exec((err, roles) => {
      roles.filter(r => !guild.roles.cache.has(r.roleID) && Date.now()-r.time > 1000*60*60*24*3).forEach(r => {
        Database.findOneAndDelete({roleID: r.roleID});
     

      });
    });
    var RoleSize = client.guilds.cache.get(Settings.Server.GuildID).roles.cache.filter(roles => roles.name !== "@everyone").size
    DatabaseLog.send(`**${moment(Date.now()).format("LLL")}** Tarihinde Güvenlik Amacıyla **"${RoleSize}"** Adet rol yedeği aldım.`)
  };
}
client.on("disconnect", () => console.log("[DATABASE] Bot bağlantısı kesildi"))
client.on("reconnecting", () => console.log("[DATABASE] Bot tekrar bağlanıyor..."))
client.login(Settings.Token.Backup).then(x => console.log(`\x1b[36m%s\x1b[0m`, ` [DATABASE] - Olarak Başarıyla Giriş Yapıldı!`)).catch(err => console.error(`[ERROR] Hata : ${err}`))
