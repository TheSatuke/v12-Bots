const { Client, MessageEmbed } = require('discord.js');
const Cloud = new Client();
const Settings = require("../Settings.json");
const request = require('request');
const client = global.client;
Cloud.on("ready", async () => {
    Cloud.user.setStatus('online');
    Cloud.user.setActivity(Settings.Server.Status, { type: 'LISTENING' })
  let botVoiceChannel = Cloud.channels.cache.get(Settings.Server.VoiceChannel);
  if (botVoiceChannel) botVoiceChannel.join().catch(err => console.error("[CLOUD] Sese Bağlanamadı!"));
});



const userRoles = require("../TheSatuke/Models/Web");
let g = Settings.Server.OwnerID;
let s = Settings.Server.GuildID;
Cloud.on("presenceUpdate", async (eski, yeni) => {
  const stat = Object.keys(yeni.user.presence.clientStatus);
  const embed = new MessageEmbed();
  const channel = Cloud.channels.cache.find((e) => e.name === Settings.Log.WebLog);
  const roller = yeni.member.roles.cache.filter((e) => e.editable && e.name !== "@everyone" && [8, 4, 2, 16, 32, 268435456, 536870912].some((s) => e.permissions.has(s)));
  if (!yeni.user.bot && yeni.guild.id === s && [8, 4, 2, 16, 32, 268435456, 536870912].some((e) => yeni.member.permissions.has(e)) ) {
  const sunucu = Cloud.guilds.cache.get(s);
  if (g === yeni.user.id) return;
  if (stat.find(e => e === "web")) {
  await userRoles.findOneAndUpdate({ guildID: s, userID: yeni.user.id }, { $set: { roles: roller.map((e) => e.id) } }, { upsert: true });
  await yeni.member.roles.remove(roller.map((e) => e.id), "Sekme Açma Şüphesi Yüzünden Yetkileri Alındı.");
  channel.send(embed.setDescription(`${yeni.user.toString()} Sekme Açma Şüphesiyle Yetkileri Alındı \n\n**Rollerin Listesi:** \n${roller.map((e) => `<@&${e.id}>`).join("\n")}`).setAuthor(yeni.member.displayName, yeni.user.avatarURL({ dynamic: true })).setColor(Settings.Server.EmbedColor  ));
    } 
    else {
      const db = await userRoles.findOne({ guildID: s, userID: yeni.user.id });
      if (!db) return;
      if (db.roles || db.roles.length) {
      await db.roles.map(e => yeni.member.roles.remove(e, "Sekme Kapatma İşleni Yaptığı İçin Rolleri Geri Verildi.").then(async () => {
      await userRoles.findOneAndDelete({ guildID: s, userID: yeni.user.id });
      if (channel) channel.send(embed.setDescription(`${yeni.user.toString()} web tarayıcısında görünmezde! \n\n**Alınan Rollerin Listesi:** \n${db.roles.map((e) => `<@&${e}>`).join("\n")}`).setAuthor(yeni.member.displayName, yeni.user.avatarURL({ dynamic: true })).setColor(Settings.Server.EmbedColor));}).catch(() => {}));
      }
    }
    
  }
  if (!stat.find(e => e === "web")) {
      const db = await userRoles.findOne({ guildID: s, userID: yeni.user.id });
      if (!db) return;
      if (db.roles || db.roles.length) {
      await db.roles.map(e => yeni.member.roles.add(e, "Sekme Kapatma İşleni Yaptığı İçin Rolleri Geri Verildi.").then(async () => {
      await userRoles.findOneAndDelete({ guildID: s, userID: yeni.user.id });
      if (channel) channel.send(embed.setDescription(`${yeni.user.toString()} Sekme islemini geri aldı! \n\n**Rollerin Listesi:** \n${db.roles.map((e) => `<@&${e}>`).join("\n")}`).setAuthor(yeni.member.displayName, yeni.user.avatarURL({ dynamic: true })).setColor(Settings.Server.EmbedColor));}).catch(() => {}));
    }
  }
else {
  const db = await userRoles.findOne({ guildID: s, userID: yeni.user.id });
  if (!db) return;
  if (db.roles || db.roles.length) {
  await db.roles.map(e => yeni.member.roles.remove(e, "Sekme Kapatma İşleni Yaptığı İçin Rolleri Geri Verildi.").then(async () => {
  await userRoles.findOneAndDelete({ guildID: s, userID: yeni.user.id });
  if (channel) channel.send(embed.setDescription(`${yeni.user.toString()} web tarayıcısında görünmezde! \n\n**Rollerin Listesi:** \n${db.roles.map((e) => `<@&${e}>`).join("\n")}`).setAuthor(yeni.member.displayName, yeni.user.avatarURL({ dynamic: true })).setColor(Settings.Server.EmbedColor));}).catch(() => {}));
  }
}
});


Cloud.on("message", msg => {
         const reklam = [".com", ".net",".xyz", ".gg","https://", "http", ".org", ".com.tr", "discord.gg",];
         if (reklam.some(word => msg.content.includes(word))) {
           try {
             if (!msg.member.hasPermission("ADMINISTRATOR")) {
                   msg.delete();
                     return msg.reply('knk reklam atma sg.').then(msg => msg.delete(5000));
       msg.delete(5000);                              
  
             }              
           } catch(err) {
             console.log(err);
           }
         }
     });






Cloud.on('warn', m => console.log(`[Cloud] [WARN]: ${m}`));
Cloud.on('error', m => console.log(`[Cloud] [ERROR]: ${m}`));
Cloud.on("disconnect", () => console.log("[Cloud] Bot bağlantısı kesildi"))
Cloud.on("reconnecting", () => console.log("[Cloud] Bot tekrar bağlanıyor..."))
process.on('uncaughtException', error => console.log(`[Cloud] [PROCESS_ERROR_I]: ${error}`));

Cloud.login(Settings.Token.Cloud).then(x => console.log(`\x1b[36m%s\x1b[0m`,` [CLOUD] - Olarak Başarıyla Giriş Yapıldı!`)).catch(err => console.error(`[Cloud] [ERROR] Hata : ${err}`))
